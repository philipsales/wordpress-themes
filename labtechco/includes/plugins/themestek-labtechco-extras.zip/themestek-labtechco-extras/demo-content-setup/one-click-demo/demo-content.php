<?php


/******************* Helper Functions ************************/

/**
 *
 * Encode string for backup options
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'cs_encode_string' ) ) {
	function cs_encode_string( $string ) {
		return rtrim( strtr( call_user_func( 'base'. '64' .'_encode', addslashes( gzcompress( serialize( $string ), 9 ) ) ), '+/', '-_' ), '=' );
	}
}

/**
 *
 * Decode string for backup options
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'cs_decode_string' ) ) {
	function cs_decode_string( $string ) {
		return unserialize( gzuncompress( stripslashes( call_user_func( 'base'. '64' .'_decode', rtrim( strtr( $string, '-_', '+/' ), '=' ) ) ) ) );
	}
}



/*************** Demo Content Settings *******************/
function themestek_action_rss2_head(){
	// Get theme configuration
	$sidebars = get_option('sidebars_widgets');
	// Get Widgests configuration
	$sidebars_config = array();
	foreach ($sidebars as $sidebar => $widget) {
		if ($widget && is_array($widget)) {
			foreach ($widget as $name) {
				$name = preg_replace('/-\d+$/','',$name);
				$sidebars_config[$name] = get_option('widget_'.$name);
			}
		}
	}
	
	// Get Menus
	$locations = get_nav_menu_locations();
	$menus     = wp_get_nav_menus();
	$menuList  = array();
	foreach( $locations as $location => $menuid ){
		if( $menuid!=0 && $menuid!='' && $menuid!=false ){
			if( is_array($menus) && count($menus)>0 ){
				foreach( $menus as $menu ){
					if( $menu->term_id == $menuid ){
						$menuList[$location] = $menu->name;
					}
				}
			}
		}
	}
	
	$config = array(
			'page_for_posts'   => get_the_title( get_option('page_for_posts') ),
			'show_on_front'    => get_option('show_on_front'),
			'page_on_front'    => get_the_title( get_option('page_on_front') ),
			'posts_per_page'   => get_option('posts_per_page'),
			'sidebars_widgets' => $sidebars,
			'sidebars_config'  => $sidebars_config,
			'menu_list'        => $menuList,
		);            
	if ( defined('THEMESTEK_THEME_DEVELOPMENT') ) {
		echo sprintf('<wp:theme_custom>%s</wp:theme_custom>', base64_encode(serialize($config)));
	}
}

if ( defined('THEMESTEK_THEME_DEVELOPMENT') ) {
	add_action('rss2_head', 'themestek_action_rss2_head');
}

/**********************************************************/




if( !class_exists( 'themestek_labtechco_one_click_demo_setup' ) ) {
	

	class themestek_labtechco_one_click_demo_setup{
		
		
		function __construct(){
			add_action( 'wp_ajax_labtechco_install_demo_data', array( &$this , 'ajax_install_demo_data' ) );
		}
		
		
		/**
		 * Decide if the given meta key maps to information we will want to import
		 *
		 * @param string $key The meta key to check
		 * @return string|bool The key if we do want to import, false if not
		 */
		function is_valid_meta_key( $key ) {
			// skip attachment metadata since we'll regenerate it from scratch
			// skip _edit_lock as not relevant for import
			if ( in_array( $key, array( '_wp_attached_file', '_wp_attachment_metadata', '_edit_lock' ) ) )
				return false;
			return $key;
		}
		
		
		
		
		/**
		 * Added to http_request_timeout filter to force timeout at 60 seconds during import
		 * @return int 60
		 */
		function bump_request_timeout() {
			return 600;
		}
		
		
		
		/**
		 * Map old author logins to local user IDs based on decisions made
		 * in import options form. Can map to an existing user, create a new user
		 * or falls back to the current user in case of error with either of the previous
		 */
		function get_author_mapping() {
			
			if ( ! isset( $_POST['imported_authors'] ) )
				return;

			$create_users = $this->allow_create_users();

			foreach ( (array) $_POST['imported_authors'] as $i => $old_login ) {
				// Multisite adds strtolower to sanitize_user. Need to sanitize here to stop breakage in process_posts.
				$santized_old_login = sanitize_user( $old_login, true );
				$old_id = isset( $this->authors[$old_login]['author_id'] ) ? intval($this->authors[$old_login]['author_id']) : false;

				if ( ! empty( $_POST['user_map'][$i] ) ) {
					$user = get_userdata( intval($_POST['user_map'][$i]) );
					if ( isset( $user->ID ) ) {
						if ( $old_id )
							$this->processed_authors[$old_id] = $user->ID;
						$this->author_mapping[$santized_old_login] = $user->ID;
					}
				} else if ( $create_users ) {
					if ( ! empty($_POST['user_new'][$i]) ) {
						$user_id = wp_create_user( $_POST['user_new'][$i], wp_generate_password() );
					} else if ( $this->version != '1.0' ) {
						$user_data = array(
							'user_login' => $old_login,
							'user_pass' => wp_generate_password(),
							'user_email' => isset( $this->authors[$old_login]['author_email'] ) ? $this->authors[$old_login]['author_email'] : '',
							'display_name' => $this->authors[$old_login]['author_display_name'],
							'first_name' => isset( $this->authors[$old_login]['author_first_name'] ) ? $this->authors[$old_login]['author_first_name'] : '',
							'last_name' => isset( $this->authors[$old_login]['author_last_name'] ) ? $this->authors[$old_login]['author_last_name'] : '',
						);
						$user_id = wp_insert_user( $user_data );
					}

					if ( ! is_wp_error( $user_id ) ) {
						if ( $old_id )
							$this->processed_authors[$old_id] = $user_id;
						$this->author_mapping[$santized_old_login] = $user_id;
					} else {
						printf( __( 'Failed to create new user for %s. Their posts will be attributed to the current user.', 'labtechco-demosetup' ), esc_html($this->authors[$old_login]['author_display_name']) );
						if ( defined('IMPORT_DEBUG') && IMPORT_DEBUG )
							echo ' ' . $user_id->get_error_message();
						echo '<br />';
					}
				}

				// failsafe: if the user_id was invalid, default to the current user
				if ( ! isset( $this->author_mapping[$santized_old_login] ) ) {
					if ( $old_id )
						$this->processed_authors[$old_id] = (int) get_current_user_id();
					$this->author_mapping[$santized_old_login] = (int) get_current_user_id();
				}
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/**
		 * Install demo data
		 **/
		function ajax_install_demo_data() {
		
			// Maximum execution time
			@ini_set('max_execution_time', 60000);
			@set_time_limit(60000);

			define('WP_LOAD_IMPORTERS', true);
			include_once( THEMESTEK_LABTECHCO_DIR .'demo-content-setup/one-click-demo/wordpress-importer/wordpress-importer.php' );
			$included_files = get_included_files();


			$WP_Import = new themestek_WP_Import;
			
			$WP_Import->fetch_attachments = true;
			
			// Getting layout type
			$layout_type = 'default';
			
			// getting layout type for correct XML file
			$filename = 'demo.xml';
			
			$WP_Import->import_start( THEMESTEK_LABTECHCO_DIR .'demo-content-setup/one-click-demo/'.$filename );
			
			
			$_POST     = stripslashes_deep( $_POST );
			$subaction = $_POST['subaction'];
			if( !empty($_POST['layout_type']) ){
				$layout_type = $_POST['layout_type'];
				$layout_type = strtolower($layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
			}
			$data      = isset( $_POST['data'] ) ? unserialize( base64_decode( $_POST['data'] ) ) : array();
			$answer    = array();
			echo '';  //Patch for ob_start()   If you remove this the ob_start() will not work.
			
			
			switch( $subaction ) {
				
				case( 'start' ):
				
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_cat';
					$answer['message']        = __('Inserting Categories...', 'labtechco-demosetup');
					$answer['data']           = '';
					$answer['layout_type']	  = $layout_type;
				
					die( json_encode( $answer ) );
				
				break;
				
				
				case( 'install_demo_cat' ):
					wp_suspend_cache_invalidation( true );
					$WP_Import->process_categories();
					wp_suspend_cache_invalidation( false );
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_tags';
					$answer['message']        = __('All Categories were inserted successfully. Inserting Tags...', 'labtechco-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
				break;
				
				case( 'install_demo_tags' ):
					wp_suspend_cache_invalidation( true );
					$WP_Import->process_tags();
					wp_suspend_cache_invalidation( false );
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_terms';
					$answer['message']        = __('All Tags were inserted successfully. Inserting Terms...', 'labtechco-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
				break;
				
				case( 'install_demo_terms' ):
					
					wp_suspend_cache_invalidation( true );
					ob_start();
					$WP_Import->process_terms();
					ob_end_clean();
					wp_suspend_cache_invalidation( false );
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_posts';
					$answer['message']        = __('All Terms were inserted successfully. Inserting Posts...', 'labtechco-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
				break;
				
				
				case( 'install_demo_posts' ):
					//wp_suspend_cache_invalidation( true );
					echo '';  //Patch for ob_start()   If you remove this the ob_start() will not work.
					ob_start();
					echo '';  //Patch for ob_start()   If you remove this the ob_start() will not work.
					$WP_Import->process_posts();
					ob_end_clean();
					//wp_suspend_cache_invalidation( false );
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_images';
					$answer['message']        = __('All Posts were inserted successfully. Importing images...', 'labtechco-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					$answer['missing_menu_items']   = base64_encode( serialize( $WP_Import->missing_menu_items ) );
					$answer['processed_terms']      = base64_encode( serialize( $WP_Import->processed_terms ) );
					$answer['processed_posts']      = base64_encode( serialize( $WP_Import->processed_posts ) );
					$answer['processed_menu_items'] = base64_encode( serialize( $WP_Import->processed_menu_items ) );
					$answer['menu_item_orphans']    = base64_encode( serialize( $WP_Import->menu_item_orphans ) );
					$answer['url_remap']            = base64_encode( serialize( $WP_Import->url_remap ) );
					$answer['featured_images']      = base64_encode( serialize( $WP_Import->featured_images ) );
					
					die( json_encode( $answer ) );
				break;
				
				
				
				case( 'install_demo_images' ):
					$WP_Import->missing_menu_items   = unserialize( base64_decode( $_POST['missing_menu_items'] ) );
					$WP_Import->processed_terms      = unserialize( base64_decode( $_POST['processed_terms'] ) );
					$WP_Import->processed_posts      = unserialize( base64_decode( $_POST['processed_posts'] ) );
					$WP_Import->processed_menu_items = unserialize( base64_decode( $_POST['processed_menu_items'] ) );
					$WP_Import->menu_item_orphans    = unserialize( base64_decode( $_POST['menu_item_orphans'] ) );
					$WP_Import->url_remap            = unserialize( base64_decode( $_POST['url_remap'] ) );
					$WP_Import->featured_images      = unserialize( base64_decode( $_POST['featured_images'] ) );
					
					ob_start();
					$WP_Import->backfill_parents();
					$WP_Import->backfill_attachment_urls();
					$WP_Import->remap_featured_images();
					$WP_Import->import_end();
					ob_end_clean();
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_slider';
					$answer['message']        = __('All Images were inserted successfully. Inserting demo sliders...', 'labtechco-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
				break;
				
				
				
				
				case( 'install_demo_slider' ):
					
					$json_message		= __('RevSlider plugin not found. Setting the widgets and options...', 'labtechco-demosetup');
					
					if ( class_exists( 'RevSlider' ) ){
						$json_message	= __('All demo sliders inserted successfully. Setting the widgets and options...', 'labtechco-demosetup');
						
						// List of slider backup ZIP that we will import
						$slider_array	= array(
							THEMESTEK_LABTECHCO_DIR . 'demo-content-setup/sliders/home-slider-1.zip',
							THEMESTEK_LABTECHCO_DIR . 'demo-content-setup/sliders/home-slider-2.zip',
							THEMESTEK_LABTECHCO_DIR . 'demo-content-setup/sliders/home-slider-3.zip',
						);
						
						
						
						$slider			= new RevSlider();
						foreach($slider_array as $filepath){
							if( file_exists($filepath) ){
								$result = $slider->importSliderFromPost(true,true,$filepath);  
							}
						}

					}
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_settings';
					$answer['message']        = $json_message;
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
					
				break;
				
				
				
				
				
				case( 'install_demo_settings' ):
					
					
					/**** Breacrumb NavXT related changes ****/
					$breadcrumb_navxt_settings						= array();
					$breadcrumb_navxt_settings['hseparator']		= '<span class="ts-bread-sep"> &nbsp; &rarr; &nbsp;</span>';  // General > Breadcrumb Separator
					$breadcrumb_navxt_settings['Hhome_template']	= '<span typeof="v:Breadcrumb"><a rel="v:url" property="v:title" title="Go to %title%." href="%link%" class="%type%"><i class="fa fa-home"></i><span class="hide">%htitle%</span></a></span> ';  // General > Home Template
					$breadcrumb_navxt_settings['Hhome_template_no_anchor']	= '<span property="itemListElement" typeof="ListItem"><span property="name">%htitle%</span><meta property="position" content="%position%"></span>';  // General > Home Template
					
					// Getting existing settings
					$bcn_options    = get_option('bcn_options');
					if( !empty($bcn_options) && is_array($bcn_options) ){
						// options already exists... so merging changes with existing options
						$breadcrumb_navxt_settings = array_merge($bcn_options, $breadcrumb_navxt_settings);
					}
					update_option( 'bcn_options', $breadcrumb_navxt_settings );
					
					/**** Finish Breadcrumb NavXT changes ****/
					
					
					
					/**** START CodeStart theme options import ****/
					
					$theme_options = array();
					
					$theme_options['classic']	= 'eNrtXW1z2ziS_nxTNf8B5629mdRZNklRsqR4vOtzvLOzlY1TsbNzqZsrFkRCEscUwVwiKTveKf_37cYbQYqU5cTO2HexR2MRbDQaD4BGo9FA6MTre5Pfisl4slNcXMZpyBOe77wsJgeTnT_0-8NROMSn4WRcJ6E3fFXigz_ZuY4jhl_d0WRntkqSXDATApawJUvLYuclnVww03jiyKwLRiMGXFzjiSsTZpyXmHBbTIBBwue8vMkEw8FkXCde0rn4rl-xj6JYkPA1nZYsXFycnKlnfB3MeFpiiWOsBjKnyzi5UcyO83jJhaT9yc6UhperrFcReCNBQZNd8leWXFyxMg7pLiloWvQKlsczBcQVBZq0VE85m68SKkByAQoUr1fmkGfG8yWmOpMdJR-K1ivif4rqeJMdT4DpuiB5nLLegsXzRanfHWiOCSsBnV6R0TBO51widbLjqArVGshz8Fe1icRBQDDnfJ4wge-BRClezhGjPmIEhcVRXdBysVpOe6s8Ec9cMNWiLLPJ_n5cIgEP-V65gLYtSna5F_Jlld6LaEmLuGT711kvBAmg_fclbUW0L5oUEkCQvUxWSXWcL1gmgOFWaARhzouCX2E33BaX8SPK2LteXDB1FzpfquRb1QMVRgUMiMubrQFSyQ3hReqt7PZSExTlTcJUHw4TWhRxKHq5owmCaZkqJQLJAzs50OrABWlOzt6cv399cXzx09kbkVZcJ4VBdqmGzx-ECF5VAiiqVZBxXDAq5qkaW7keji7UDLsG6LygWPDroOAhaImdl1OhwfB1nM54UYJCCRI2KyupDqCIwyi-XCKiYj_sLFkU0x7S7BzZ6TE0zc4ROYx1Qln0qjbEt71swUFJhDRJIOt-DB_Ir_-_VoQU_uhwMTy6XDBFLDKTw314PFxc9I_-0_X6_mB4MBpjWh8KFmyE7nHs2gg2VXVGD1cdll6xhIOav19lTpc0TshxFOWsKKoKocR_rgYDDIE7KiZcMLEqNnywiiU8pNiLelmc3rNyZ7NZHLL12rkeueBlGacwHb35sEvenx-vV8-rdWaaMxrUZpSho1Gw-_wUVJ-eQ5qTvnewTrsqSr6ssriAWz6f0u-dXfG713df6KxSXQRdpYFeiGh-Oc-ZmHz7fmeORpk41c3EjxxiMMElfEqTXDBcJ_R5zldphNriXDC1hW1AKH10oJJqugurwTJGy7risjWCSkW1REvoQws0bqwXKL-a21VKc37WQt9K3OI0Rc30hIXWulrYVtgmwm4QGtTV9p5-AcKplrLLhXl8NqV5r1O1KoKN_RD1uCR6KlgJkISxsN7K2ky-tQRHPVPVD1LFJKuHrUXS0tWjqA8_uqsL2gVNowT6jtBGgMQQkUBjJp7mNL9ROXGWj2c3egZTL4WBTK9ZwZdMj-AZJTPao3nOr3sRv0416DpLg5N6xNJJGfdwnBpjVeUo5lI2qCC0sHxcIvJP72eeXCfRz3rJYEl2FeIczYCmUFVIYjA6pHHdt7iXRWCUbjBdFZCpKAJdXCJS1tSyppD6OV2FCaNyueH1WxANwoQX7LNx9eu4rrINqKJWbqCqhHiWsJp-L-Fs7ffuGklgquzLqUHQaVawpJwzMYhWS7DlzPITqtMPxK8ZTqCSYK6co96ZwjR4mfE41UtV13PkPDjuXCLsVVrMoscqlTxrqqrGJIbFW1R3TlxcinaDevAbRC0sHfGjx7KirpuhI6A7XFwlxmjhci1AQzA8vv3mMAEb5S7LU5oyYEtKU3JCjAl5uA_57-aChluPJqWyiShZ5Gz2A5jiRz-h8XYMjOmUlWi7He7TI811f5UcNeCqG6WDft10EyUXsNBmWS8Vgv8PJEmTvYdrgOJ_K6up4rqhq_gtNB29pG8spsr2gjTXGTQXJFZcJ8KlkHAZZGC1yeIta67N6urXrS5hcvUxkRUZDPP4igUbco9Vbs_dlf85e-PhC-0BURktVvVRbA1Ooc3Q6bKkH9uMTZSzZtPpJZNlhcpsZm0pco8djUHdXCK0QauNknEb5cbRh8wbotdlGDYbtFww7RYuzKIPhRMpQZxmUhV5MPwubjJGQBVH5GLBUvJWGPKnacmMuSxzoXcoKOMysS2X2mJbFffVG2F5I5TDpmDceAjcBUy4PJUePOyQctnQNZhxwC_ZnFwiVQ9NuFxczJiqW3pr2TvGORLSOEXibocjtvY7PuUlXCdcJzyNWFqw6AGdj8DlQInT6niEdlllGctDKmfVFg-k63d7IN3hRg-k22b7On136rONHkjP6AQbwA4uOKI0WVwwsxVqI1ThNW2EawWtXDDbiRuawJeaQDdRlPMMrd7NjWna8mFbcPC5Leh9WgtC0c7eoLUNx-7Qo5vbUKG2dbO0E7co6GqPAWcpk-2hFn7AM-W96rmxAkSFEjJU1gQm_IdYDDI2c2cD0_F1V5O-DbBQaE5Lg5ixXCLdSkdpu1dNFW09EyrxD54klzxPv6B26d7WcA8eVqlUk3Z3h3RbO0vgPl2fSpfI3vMTuf_8RPafn8iD51wn8vD5iXzw_EQePT-Rx09YZK9jKnGerszCi4EGQtM91eJZEA5cXEO72a5yHeeR1nZagt50vvdrNn8Y661vrDf553MNuBY3y20DwA2eO9dcIkMXAlg5JjgFpHp-i0V_1G3XDUb3t-uiaDxWGxvAgSZJD-WVEUOCqWzWbqPPtxAuVtPfH-TPCwdyxxvCgbzfGV_0iERhvlpOg6e1Rt6A5wbnhuffP7yKwY9sh07IsM4GsquYXStqEUigdxEqpWB5iG1fsyHAKLoKeCV6yjVcJxpdBSUShqB581Br9xNasjnPb8hxHi5gtV1MyFqOks51Dijxgs4bxLhYNcSgZEsZmDOL5XhBMd9CakGqdAKzCMtVWSMrO12VC57r4lwwyWOR0CzRUbGDMhqwNo1Za2MTYliRYUTMo3oFtptXcKMq_ijx2WJywfqKyaXv7LruYNcdY_jE-EW1gSYrGJZ00z4vumI279v9v9r7HXqbNinJhv1Lls7hSYWhusMa_sZPj_3-51Ny_A4-_zj-6fXxf70-JX85e0c-nL3XNbLywaTUdPGLDcqKYroqS25FsTlcIort4vjkgrw_76avh7LJXjCL86LUw-KubVK3Qd812sbrdI893DpN4o4B1hFs487wt9rlt2tRt9rs3WYMW8JOGHUCCeX4gR_4ZoeqRn7Xtp7TkuGzAX2seCV37E7dqbEF6oJ3YwiggA2Art3tQVnL8LSVegdgzhB-fQNYvVLdgLnVEOfZjdzdNhYDDu0TnUz-AyleEs9xR8Rsod97hbZz9FqnkVcqDffc98hxkhBRUkFyBhbZFYv2mmrIyFhFcUHl1zbZteE5ZynLabLJLIe2gonhkpxTqf3bTUfcXaULvgSD8UfgefW4xvjgYY3H0Wjcn44_3RjHrom49uwoOexBC21cXIhgPEPRs-ruyyARPeNbRCYzijh1w7HTN3EK7tqq9cntcHY3X9_pbj7fuX_zbbGxKUDznjNom86j9IePB1r_WYO2YQO27z0eaP5zBs3d4EryRo8H2uBZg_bA_oxtQRs-a9A2TATeI00EKnbvd3f49j8NMn8DZIPPguwTTR9g-Gzcu9uE7Iweq0t-XCK-HjIU-zUbRvh2NvqXdO-Ovrw6dMVZZ4zHec5Rf57zuyCnfFcaueET3p3ZXFz_je5_deq9CtgaPlc15d-placJn0u_RhIvYxPsrhZfI0WAGxhLnlenLaGwd5BG_g6J6lkQ6g2TxjlgX76e8o_KG6f6YLnImVF7mkLzGIuY_Z7xG6EPEPcx1NndoFhQlEh7Z7E255hEykVcXBCk1K4Z5KzECZaspFDXojTHkUFWltJpwlwikwQ4yS0PBdqxecDdITpXsF7QeaHvPIjiwvAQ4d7CPVTqMfVKfUWfFa0cxXKfXCdm2mMe8qX2W43QabRU1y_c3krP5lpNsAjsETU3oue3UILY0uesAqXbaEC0Gk1biRIYm8w9qBrvM-FtA60D309Esr0JlYu5Vot2aJ0GVRPW5vsmpM1S1uHE81IZz8sZT2IeZDn_lYVlEAFxnBS6p799d_a305ML8ur04vin1-fa01_lw1FkH8sX33ue9gRWhOI4fM4SqG1kS1lRqJfWUEPtd_r6-OL0FVGCnK8z1tksnWAL4bfRtmuHdr4ouNLpxuWVzTRQYi9K-Z_x3hJ9CMNdI7Lq1Ue1Jo9tkDdU7rBhizZzbNjNc12pbu09uu7tOxCZLbPyZtOWndhwrp9Jfz5nClm5oClPxCiWg5uqQa9PZdziJTLbtA560ZPY2nH42iqP2ireVq0yqqIVvrbLI7XLSEx1CmNomf722uz0_PT43clfycWHt6df2-chT0h3jhv__q3zAf58bZ0v0jqDrVvnFUviK5bfwFwiXCf6agl8mTlnuO2c81qB8LVdvkC7qMVnY81gL8PNwmFUI2tdqKuVVN-pkcbpPAFcIp7JO8GaMVfjDcQ6lMoKl8lm0BbrKw9X-xrk-w5fhMlvrTDGOkgCIyrikBVBawGebsMaWVUOrj2veSuvZmFcIo6U0WXAPpY5rfXuQvVsua4RS2oEqIPa0mpQc30zFd7YUK24O4zye7AGsc_CcJWJITDZyNm7N-fTjxlDf3jINnPu3xuOE54zcn4ZXCdJsZm1fz_W0NBcJywv41mMltsdvAf34w398zRahXdcIg3Dtu8qhku2nOINCHLkqJtD6kGLMo383WCDGTcMI7-i6HbqaYq1oeTjLpV_1_GV8eCRTq9A2Q96cOVBjx2jbhCBxeNdz9v1vV1nb_TCHBNiec5zgV08f7h5TsSJikBicSlF0eN3xhL_nzEW11A14wKD5I9_PCVvzi7IX87ev3ml7Q1DjjdcMK6WVg7gdc7z_GaXTFclAbxIBj2L3PAVQed0wvklDEIy4zmJOCtIykvCPsZFSSAlZ0uOAXvkLQhXMLKCj_JHzcEYTcmUJfwa-hiZxWlErhe0XFzjDGwwG5aMdykQDPDe0w1m5G7cheLrW01SUIjFKlGRi9CF8PbCN7xcXEihYaCKawsPsyOrlql6v6RluGARipRruWFMLAtToRLsaTpHsa7jckGw95Eons0YhpKSS3ZzzfOo2Dvcz460Cimgj-gzDGuXz9nvlc5o3vup31t6sHGmAz2uLVQBKqasef7jwJZIWSS1cx0Y5bhGEYSWk6QmoVW2sgea0vlrFDVutnA1UtnA9okTlF3aZDgGCuOo92u2hFwwTZluqrxUOUPx6AYN2RS6moG3Ttm4otWyIzawxcOP0B90DO8WXFy9Lbjijl0Sh5dbM-1vh1ww5oNRn97BVh7tVMcNV4h3ma9CVJXVXFyO8_MFblfhvEXg73s8gYN7ioZYb8TVOSzKZVwiu65XvztrJa7pAm0Mo0HPguKGsDpN22txyxZezqNu16pnKlgmXFzqR-blwtXvVGDHzhFoyNN3BG_xvXj3_gRv8QVt4Qpi3zAygSA7oEOWTKoONRXJzbtrekNgbmegN85L-F6uUhb9O7DyxX1iqvzq4lS_Cc-dp2Ify66oifGlLYx7nl8SF46LH3Nsuo5iCNNpqJwfBwfA8c_xEjUaWeXJ9798h1wwFoAgWhLFntxYpllcXAj4IO-f5Bb4D2fFNU1cIpg2nd0-fHz4DOAzhM-B4_zy3YuX336z1-iTv337zb_p6k8InRZgYZYMCAn8XDBcMBMycP6oHlH72c-9Sxwd1W75hIivuGv03987f3xRPX74vgfZXuh8S_7PT8lVfEImfv887RkERVuWW1wwFQP6QzGkSbycI6ZL-lFFi0zIgZd9lIQLd08NyV148PeqISrz5PM4hfkB24RGmCweRLiBbOMJ-eU72cy_fGeHNjTZ_yarYgIVJmToCCFEO1ahLCBcXJUuqK9NuqOSpVg91RkMtUqWXCc34I14sZ2oUtj26stysOxbvcDLZgH-KweVNh_jkUrbJPAaRGL9pcM6mtSuRV0kq7miyVpocEVVnWhzLEakvhGu3GiGviZcMM4qaxnN0kFl05K4tmenZ9sf-EbPfXU84MW5cnFUR7OahDWRDkyOho-kDkuV3iSrIeNWAjRxGbZkqYMzXFzLe1Pd_1flNPhU6XV0BmoFXocGQw8gtebo6cDEXCJ1a6S6aJVorg9FAmG61p0oyIT8iOmFNnqbpHUEHDtPrS4yi6m6I5N7xl7GO9_iVKwT1fpioP0StUnFitVSb39df2myolYXgcyNeAzr7ZRHN7hUtBfc2AsaJCyt8XDFnYRxGmwQcbxWgUDNw9VkLmfHRsWynMkLtpUPZCr-EZWxuhPXTsNGEp5VeVWpTq4f4p8HMzAQVjmLAnGVt6LBsJPqfD9aQEL_GdbmXCJO_S-1qHTHPptquA3bXCKtCjOUJRXarh2-3iap1fxqeVI0rhivGR4mWx8jX5lY2QXi1JsFiThaH8F6OdCRrzyrMt_-CyHZrKo';
					$theme_options['infostack']	= 'eNrtXW1z2ziS_nxTNf8Bp629mdSZNklRsqR4vOtzvLOzlY1TsbNzqZsrFkRCEscUwVwiKTveKf_37cYbX0TSdmJ74rvYo7EINhqNB0Cj0WggdOYO3dlv-Ww6G-QXURLwmGeDl_lsfzb4w3A4ngRjfBrPBjG95psCH7zZ4CoKGX51JrPBYhPHPib4LGZrlhT54CWdAdNoZsusK0ZDBlxco5kjExacF5hwk8-AQcyXvLhOBcPRbBCt6VJ816_YR1EsSPiazgsWrI5P1TO-9hc8KbDEKVYDmdN1FF8rZkdZtOZC0uFsMKfBxSa1SgJ3XCIoaLxD_sriS1ZEAd0hOU1yK2dZtFBAXFxSoEkK9ZSx5SamAiQHoEDxrFwigzwLnq0x1Z4NlHwompVH_xTVcWcDV4DpOCB5lDBrxaLlqtDv9jXHmBWAjpWnNIiSpUidDWxVoVoDuTb-qjaROAgIlpwvYybw3ZcoReslYjREjKCwKKwLWqw267m1yWLxDFCtilwine3txRLwgO8WK2jbvGAXuwFfl-lWSAuaRwXbu0qtXDAkgPbfk7Ql0Z5oUkhcMEF2U1kl1XGesExcMMMp0fCDjOc5v8RueFdcXKaPKKN1tQLqLnSequQb1QMVRjkMiIvrOwOkkhvCi9Qb2e2lJsiL65gpBlGy4HkBA1P0c1uT-PNcIlFqBJJH1WRfKwQH5Dk-fXP2_vX50flPp29EWp0UhtmFGkB_EEK4ZQmgqjZ-ygGqiFwnanRlekA6IBp2DtB6fr7iV37OA9ATg5dzocOcquR-zBZFKdU-FHEQRpckiGme_zBYszCiFtIMDqvpETTO4JAcRDqhyK2yFfGtla44qImAxjFk3YvgA_n1_7eKkMIfHqzGh-egikVmcrAHjwer4eF_Ou7QG433XCdTTBtCwYKN0D52tTaCTVmdycNVhyWXLOag6O9XmZM1jWJyFIYZy_OyQijxn8vhXDCD4JaKCUAqFRs_WMViHlDsRVYaJfes3OliEQVsu3aOS855UUQJTEhvPuyQ92dH29Vza52ZZoz6tTllbGsUqn1-DspPz1wizWnf3d-m3eQFX5dZHMAtW87p9_aO-N0dOi90Vqkw_K7SQDOENLtYZkxMv0OvM0ejTJzsFuJHDjGY4mI-p7GPU_oy45skRG2xj9qiakIojbSvkmraC6vBUkaLuuqqagSVimqJFtCHVmjeVF6g_Gp2VynNGVoLfSNxi5IENdMXLLTW1sK6wjYRloPQoI62-PQLEE61VLVcXJjJF3OaWZ2qVRH09kPU45LoS8FKgCTMhe1W1obyTUVw1DNl_SBVTLN62FZIWrp6GA7hR3d1QbuiSRhD3xHaCJAYIxJozkTzjGbXKlwnzvPR4lrPYOqlMJHpFcv5mukRvKBkQS2aZfzKCvlVokHXWRqc1COWTorIwnFqzFWVI19K2aCC0MLyicg_1s88i8Of9aKhXCLZZYBzNAOaXFxVIY7A7JDm9bDCvch9o3T9-SaHTHnu6xKRsqaWNYXUz8kmiBmVCw532IKoH8Q8Z5-Nq1fHdZP2oIpauYGqEuJZwmr6vYSztd87WyS-qbJcJ6cGQadZwaJyycQg2qzBljMLUKjO0Be_ZjiBSoK5col6Zw7T4EXKo0QvVh3XlvPgtIvQKrVYhR6rVPC0qaoakxgWX6G6deJStD3qwWsQtbC0xY8ey4q6boZOgO5gExujhcvVXDANwPD49puDGGyU2yxPacqALSlNyRkxJuTBHuS_nQsabhaNC2UTUbLK2OIHMMUPf0Lj7QgY0zkr0HY72KOHmuveJj5swFU3SkfDuukmSs5hqc1SKxGC_w8kSZPdwjVA_r-l1VRy7ekqXgtNRy8ZGouptL0gzRnazQVJpRPhYkg4DVKw2mTxFWuuzeoa1q0uYXINMZHlKQzz6JL5PbmnKrfr7Mj_7N3p-IX2gaiMFVb1UVxcGZxCm6HbZU0_thmbKGfNptNLpooVKrOZ1aXIPbU1BnWLsApabZRM2yh7Rx8yb4hel0HVXDBlXDC1Fqz8KEmlxnFhlJ1fp4yAxg3J-Yol5K2w10-SghmrWOZCN5BfREVcXDVQaqtqQfbV7VBzOyjPTM64cQQ4K5hXeVwiXXXY7-TqoGvM4rhesyVFKgsttUxMjKr3uVvZO4YzEtIoQeJuz1witvY7PucFXCfHPAlZkrPwAb2MwGVfidPqYYR22aQpywKasw5Xo-N1uxqdca-r0elbyPS4Gl0z9KtcMNbnraEz95geUZrMh0kJlQ5q6nLwAkHZQqjp2skbQ96TsupGCjOeonnb35ymNR-2DUef24bup7UhFG3vjtpa0Z46Y5f2t6JCrbthPLlW083STtyiicvtBJyOTLaHWuEBz4Rb5XNjqYcqJWCorgnM7A-x6mNs4SxGpuvrriadGGCK0IwWBjFjLjqlltIGrpos2nomVOIfPI4veJY8oX7p3sFw9p9erTitncV3vlxc50mXyO7zE3n4_ET2np_Io-dcJ_L4-Ym8__xEnjw_kadfsMhux1Rif7kyC3cFGghNP1SLC0F4ag1tv13l2PYjre60BNZ8uftrunwY621orDf553MNuBZ_yk0DwB4XnVMhQ_cDWDkmDgWken7LRW_SbdeNJve368JwOlU7GMCBxrGF8srgIMFUNmu30edVEM43898f5M-L_HGmPZE_7u-ML_pEwiDbrOf-l7VG7sGzx73hevePpGLwI9uhEzKss4HsMmJXilpEDOjtglIpVFxcwe6odCobAgyYK4FXolwnXFxzouGlXyBhXDCaNwu0dj-mBVvy7JocZcEKVtv5jGzlKOhS54ASz-myQYyLVUMMSrYQXvRoEcnxgmK-hdSclOkEZhGWqbImlex0U6x4posDJI9EQrNEW4UJysC_2jRWWRubaMKSDENfHtUrcLd5BXekoo8SnztMLlhfMbkM7R3HGe04U4yTmL4od8pkBYOC9m3ooiumf4Pu_9Um79jt240kPRuVLFnCk4o4dcY1_I2nHvv9z1wn5OgdfP5x9NPro_96fUL-cvqOfDh9r2tUyQeTUtPJL3ZcIkuK-aYoeCVcXM0W4WrnR8fn5P1ZN309Zk32gkWU5YUeFrfthzoN-q7RNt2me-zh1mkSdwywjqgaZ4G_5XZ-tRZ1q626rYzxSdgJw04goRzP93zPbEXVyG_bv7NbMnw2oI8VmORMnbkzN7ZAXfBuDAEUsAHQtXt3ULYyfNlKvQMwewy_ngGsXqluwJxyiPP0Wm5jG4sBh_axTib_gRQviWs7E2L2yu-9QhscvtZp5JVKw831XXIUx0SUlJOMgUV2ycLdphoyMpbhWlD5rd10bXguWcIyGveZ5dBWMDFcXJAzKrV_u-mI-6t0xddgMP4IPC8f1xgfPazxOJlMh_Pppxvj2DURV6saDoc9aKWNCxF1ZyisSt09GQ2iZ_wKkcmMXCLOnWBqD01AgrO1av3i9ji7m08FVrQ2n2ffv_nKTcnuFkLQ3OcMWt_Rk-H48UAbPmvQejZgh-7jgeY9Z9CcHleSO3k80EbPGrQH9mfcFbTxswatZ1wicB9pXCJQQXq_u8N3-GmQeT2QjT4Lsk80fYDhs3Hv3iVkZ_JYXfIT8XWRodiv6Rnhd7PRn9K9O3l6deiIY80Yj_Oc4_5cXPt3QU75rjRy4y94d6a__r3uf3XAvQzYGj9XNeXdqpXnMV9Kv0YcraNmVPtEEeAGxppn5bFKKOwdpJG_Q6J6FoR6wwQqILcVzAYFvp7zj8obp_pgscqYUXuaQvOYiuB8y_iN0AeI-xjqkK6fryhKpL2zWJszTFwixSrKCVJq1wxyVuL4a1ZQqGtemHPHICtL6DxmoUkCnOSWhwLtyDzg7hBdKljP6TLX1xuEUW54iIBv4R4q9Jh6pb6iz4qWjmK5zxMx7TEP-Fr7rSboNFqrmxZubqRnc6smWAT2iJob0fVaKEFs6XNWodJtNCBajaatRAlMlczZLxvvM-FtA60D309Esr0JlYu5Vot2aO0GVRPW5vsmpM1StuHEg1Epz4oFjyPupxn_lQWFHwJxFOe6p799d_q3k-Nz8urk_Oin12fa01_mw1FkTuCLM7vw3XK1XCewJBTn3jMWQ23DqpQlhXpZGWqo_U5eH52fvFwiSpCzbcY6W0VcJ1SF8Npo27VDO18UXFzpdOPyShcaKLEXpfzPeEWJPobhbBFV6jVEtSYPbpA3VO6wYYs2c_Ts5jmOVLfVPbru7TsQma3T4rpvy05sONcPnz-fw4OsWNGEx2IUy8FNG1H_N3hfzF1aB73ocVTZcfjaKo_aKu6dWmVSRit8bZdHapeJmOoUxtAyw7trs5Ozk6N3x38l5x_ennxtn4c8Ct05brz7t84H-PO1dZ6kdUZ3bp1XLI4uWXYNi5zwqyXwNHPO-K5zzmsFwtd2eYJ2UYvPxpqhugw3C4dJjax1oa5WUkO7RholyxiIeCov_2rGXFxNe4h1KFUlXFwmXUBbbK88HO1rkO87fBEmf2WFMdVBEhhREQUs91sLcHUb1sjKcnDtecVbeTULE3GkjK599rHIaK1356pny3WNWFIjQB3UFa0GNddXUOHVDOWKu8MovwdrEPs0CDapGAKzXs7uvTmffEwZ-sMD1s95eG84jnnGyNlFFMd5P2vvfqyhoY9ZVkSLCC23W3iP7scb-udJuAluRRqG7dBRDNdsPWeZHjnqipB60KJMI3832GDGnmHklRTdTj1NsTWUPNyl8m47vjIdPdLpFSj7QQ-uPOixY9QNXCKweLrjujueu2PvTl6YY0Isy3gmsIuWDzfPiThREUgsrqXILX5rLPH_GWNxC1UzLjBI_ujHE_Lm9Jz85fT9m1fa3jDkeNXfZl3JAbzOeJZd75D5piCAF0mhZ5FrviHonI45v4BBSBY8IyFnOUl4QdjHKC8IpGRszTFgj7wF4XJGNvBR_qglGKMJmbOYX0EfI4soCcnVihZbnIENZsOS8S4FggHeu7rBjNz6ehLlwvX0vSYJKMR8E6vIRehCeE3hG16spNAwUMX9hAfpYaWWiXq_pkWwYiGKlGm5YUysc1OhAuxpukSxrqJiRbD3kTBaLBiGkpILdn3FszDfPdhLD80tLdBH9BmGrVvmqu-Vzmhe8KnfV_Rg40wHelxcW6h8VExp8_zHflVcImWR1M51YJTjFoUfVJwkNQkrZSt7oCmdt0VR41YVrkYqG7h64gRllzYZjoHcOOq9mi0hQFOmmyovUc5QPLpBAzaHrmbgrVM27mKt2BE9bPHwI_QHHcN7B67uHbjijl0cBRd3Zjq8GwKYD0Z9cgtbebRTHTfcIN5FtglQVZZzOc7P57hdhfMWgb_v8QQO7ikaYr0RV-ewKtax7Lpu_ZKsjbiPC7QxjAY9C4qrwOo0ba_FdVp4PY-6RqueKWepcKkfmpcrR79TgR2DQ9CQXCfvCF7Xe_7u_TFe1wvawhHEnmFkAkEGoEPWTKoONRXJzbsrek1gbmegN84K-F5sEhb-O7DyxMVhqvzyhlSvCc-tp2Ify66oifHUFsY9zy-Ju8XFjzk2XUcxgOk0UM6P_X3g-OdojRqNbLL4-1--Q1wwc0AQLYl8V24s0zTKBXyQ909yC_yH0_yKxiFMm_bOED4efEbwGcNn37Z_-e7Fy2-_2W30yd--_ebfdPVnhM5zsDALBoQEflwwgBkZ2X9Uj6j9qs_WBY6Ocrd8RsRX3DX67-_tP74oHz98b0G2Fzrfmv_zU3Lln5CJ3z9PewZB0ZblBkDFgP5ADGkSrZeI6Zp-VNFcIjOy76YfJeHK2VVDcgcevN1yiMo82TJKYH7ANqEhJosHEW4g23hGfvlONvMv31VDG5rsf5NVMYEKMzK2hRCiHctQFhCuTBfUVybdVslSLEt1BkOtkuXJDXgjXtxNVClse_VlOVj2jV7gpQsf_0GDUptP8Uhl1SRwG0Ri_aXDOprUToU6jzdLRZO20OCKqjzRZlcYkfpGuHKjGfqaXDA4q2xlNEsHlU1L4lQ9O1bV_sA3eu6r4wEvzpSLozya1SSsibRvcjR8JHVYyvQmWQ0ZpxSgicu4JUsdnPFW3uvyBsAyp8GnTK-jM1Ir8Do0GHpcMKk1R08HJhVSp0aqi1aJ5p5QJBCma92JgkzIj5iea6O3SVpHwK7mqdVFZjFVt2WyZexlvPUtSsQ6Ua0vRtovUZtUKrFa6u2v2y9NVtTqXCKQuRGPUXk75-E1LhWrC27sBQ0SltR4OOJWwijxe0ScblXAV_NwOZnL2bFRsTRj8iZt5QOZi38vZaouv62mYSMJz6q8k9Qkl1ePlos2u3nSfL70F2A5bDIW-uIyb0WD8SjlwX80jYRiNMzNVZz6X2tR6Xb10KrhNm4LwcrNGJdUaNR2OIGbpJV-odYteeOS8ZpFUoUEb_lHi8EXx-EqkIgz9yEspH0dEsvTMvPNv1wwkuuvSw';
					$theme_options['overlay']	= 'eNrtXXtz3DaS__tSle-A09Ze4jqNxNc8rWhXXCdrs9nyWi5L3pzrcsXCkJgZRhyCRXIka1P67tuNF0EOZyTZkiPdWcpEQ7DRaPxcMDQajQZMXCee701-K1wn48lOeZFkEU95sfOynAxcJzt_8P3BKBrg02Cyk9JrvqrwIZjsXFwlMcOv7miyM1ulaYgJIUvZkmVVufOSToBpMnFk1gWjMQOuycSVCTPOK0y4KVwnwCDlc15d54Jhf7KTLOlcXHzXr9hHUSxI-JpOKxYtjk_VM74OZzyrsMQxVgOZ02WSXitmR0Wy5EJSf7IzpdHFKu_VBN5IUNB0l_yVpZesSlwiuktKmpW9khXJTAFxSYEmq9RTwearlAqQXFyAAsXrVQXkmfFiianOZEfJh6L1yuSfojreZMcTYLouSJ5krLdgyXxR6XdDzTFlFaDTK3MaJdlcXKROdhxVoUYDeQ7-qjaROAgI5pzPUybwHUqUkuUcMfIRIygsiZuCVovVctpbFal4hoRFVeWT_f1UAh7xvWoBbVtW7GIv4ss6vRfTipZJxfav8l4EEkD770vammhfNCkkgCC9qwVQ7-WyYqr7fPGSARi3RiaMCl6W_BK75FeMbIyCGqMSBsfF9d0B8h9RzE3QPH6ZN3L4So1WVtepVIM4MFNalknUw24EulIkO5oynFaZ0oqSuk4OtX5zAdLj0zdn71-fH53_dPpGM7ZIQWtcXCh98Achi1eXXDCadxXmHKqU8EzpgQgqxaSmgvZRkoXlgl-FJY9A7-28nAqdjK-TbMbLClRkmLJZVYs1hDIO4uSSiBr-sLNkcUJ7SLNzaKdcJ4DiziE5SHRCVfZquPFtL19wUHsRTVPIup_AB_Lr_68VUQjteHiwGByew9RcIjKTg314PFj4h__pen7QHwxHY0zzoWDBRmhTx66NYFNXZ_Rw1WHZJUs5TFxc96vMyZImKTmK44KVZV0hlPjPdb-F3npLxQQgVsUGD1axlEcUu1EvT7J7Vu50NktcIrZeO9cj57yqkgwm2Dcfdsn7s6P16nmN3kwLRsPGHDlwNAp2p5-CAtezYtuM8YbrtKuy4ss6iwu4FfMp_d7ZFb97vvtCZ5VKL9xUGuifmBYX84KJ8e4HG3O0ysTJeyZ-5BCDKTvlU5qGaKLMC77KYlQXQ1QXtkmklO1QJTU0MFaD5YxWVhoIaKsElYp6iVbQhxZorlkvUH5lraiUtsWhhb6RuCVZhqrpCQstkm6UtYhtXCIsIaFCXW3B6hcgnGopu1xcmFRmU1r0bJmghEL3S02wtR-iXCKXRE8FKwHSpZwd2q2sDf8bS3DUM3X9IFWYCnrYWiQdXT2OffjRXV3QLmgWp9B3hDYCJAaIBJpkybSgxbXKiRNyMrvWM5h6KUx-esVKvmR6BM8omdEeLQp-1Yv5VaZB11lanNQjlk6qpIfj1JjfKkc5l7JBBaGF5RORf3o_81wijX_WiyBLsssIXCdpBjSlqkKagOkklwu-xb0qQ6N0w-mqhExlGeoSkbKhljWF1M_ZKkoZlQsoz-9ANIxSXrLPxjVo4rrKt6CKWrmFqhLiWcJq-r2Es7Pfu2skoalyIKcGQadZwVwiec7EIFotwZgzC2qojh-KXzOcQCXBXFw5R70zhWnwXCLnSaYX367nyHlwvImwV2sxix6rVPG8rapakxgWb1HdOnEp2i3qIWgRdbB0xI8ey4q6aYaOgO5glRqjhUuznUZgeHz7zUEKNsptlqc0ZcCWlKbkhBgT8mAf8t_OBQ23Hk0rZRNRsijY7AewxQ9_QuPtCBjTKavQdjvYp4ea6_4qPWzB1TRK-37TdBMll1WvZHkvE4L_DyRJk72Hi4Dyf2urqea6pasEHTQbeolvLKba9oI01-m3VyRWXCfCRZFwguRgtcniLWuuy-rym1aXMLl8TGRlDsM8uWThltxjldtzd-V_zt548EL7dFRGi1VzFFuDU2gzdCMt6ccuYxPlbNh0eslkWaEym1khi9xjR2PQtAht0BqjZNxFuXX0IfOW6E0ZBu0GLUG7RQuz6EPhREqYZLlURR4Mv_PrnBFQxTE5X7CMvBWG_IlZSQ50LvR3hVVSpbbl0nAZqOK--lQsn4pyO5WMGxeBu4AJl2fSXCeJHVIuGzYNZhzwSzanSCXcDYWYMVW39NaybxjnSEiTDIk3u1Cxtd_xKa84OeZZzLKSxQ_oTgUuQyVOpysV2mWV56yIqJxVO3yqbrDZp-oOtvpU3W0rnC0-Vc_oBBvA5oTmu9OA6RGlyUKYrVAboQqvRzU6akwLoQrsJm_pgkDKqhspLniOdu_25jSt-bBt2P_cNvQ-rQ2haGev39WKztgdeHR7KyrUNjdMIBdxulm6iTtUdL1vgvOUyfZQSz_gmfFe_dxaA6JKkY4_AlP-QywHGZu5s77p-rqrSe8G2Ci0oJVBzNiRbq2ltOWrJouungmV-AdP0wteZF9Qv2zeqnGHX16tuJ2dJXSfrldlk8je8xPZf35cIgfPT-T-8xN58PxEHj4_kUfPT-TxExbZ2zCVOE9XZuHHQAOh7aDq8C0IF66h3W5XuY7zSKs7LUFvOt_7NZ8_jPXmG-vN2r39DAOuw9Fy0wJwi-_OtcjQiVwwVo4JuAGpnt9yMRhttuv6o_vbdXE8HqutDeBA07SH8sooKMFUNutmoy-wEC5X098f5M8LcXLHW0KcvN8ZX_SJxFGxWk7Dp7VG3oLnFveGF9w_ZIzBj2yHjZBhnQ1klwm7UtRcIpRA7yPUSsHyEQ8tb7MhwMjAGnglesY1XCcaX4YVEkageYtIa_djWrE5L67JUREtYLVdTshajorOdQ4o8ZzOW8S4WDXEoGQrGaMzS-R4QTHfQmpJ6nQCswgrVFkjKztdVQte6OJcMMkjkdAu0VHxkDLCsTGNWWtjEzZZk2FMzKN6Be42r-BWVfJR4nOHyQXrKyYX39l13f6uO8ZcMIrxi3oLTVYwqui2nV50xWzfuft_tfs78LZtU5ItO5gsm8OTCq11Bw38jace-_3PXCfk6B18_nH00-uj_3p9Qv5y-o58OH2va2Tlg0mp7eQXW5Q1xXRVVdwKZHNEINv50fE5eX-2mb4ZzSZ7wSwpykoPi9s2St0W_abRNl6ne-zhttEk3jDANoTbuDP8rff57Vo0rTZ7vxkDl7ATxhuBhHKCMAgDs0fVIL9tY8_pyPDZgD5WxJI7dqfu1NgCTcE3YwiggA2Art27g7KW4Wkr9Q2AOQP4DQxgzUptBsythzjPr-X-trEYcGgf62TyH0jxkniOO1wiZhP93iu0ncPXOo28Umm4675HjtKUiJJKUjCwyC5ZvNdWQ0bGOo4LKr-2za4NzznLWEHTbWY5tBVMDBfkjErt32064v4qXfAlGIw_As_LxzXG-w9rPI5GY386_nRjHLsm4tqz4-SwBy20cSHC8QxFz6p7IMNE9IxvEZnMKOLUjcaOb1wiFdy1VeuT2-Pc3Hy-s7n5Auf-zVdvSm5uIQTNe86gbTtj4w8eDzT_WYO2ZQPW9x4PtOA5g-ZucSV5o8cDrf-sQXtgf8ZdQRs8a9C2TATeI00EKnrvd3f4-p8GWbAFsv5nQfaJpg8wfDbu3buE7Iweq0t-XCK-HjIU-zVbRvjdbPQv6d4dfXl16Irz2xiP85zj_jznd0FO-a40coNcJ7w7s73-W93_6iR_HbA1eK5qKrhVK09TPpd-jTRZJibcXS2-RopcMDcwlryoz1tCYe8gjfwdEtWzINQbJkNzJFhXXDBfT_lH5Y1TfbBaFMyoPU2heYxF1H7P-I3QB4j7GOr0blguKEqkvbNYmzNMXCLVXCIpCVJq1wxyVuKES1ZRqGtZmRPJICvL6DRlsUkCnOSWhwLtyDzg7hCdK1jP6bzU9zjESWl4iIBv4R6q9Jh6pb6iz4rWjmK5z5Mw7TGP-FL7rUboNFqqKyVubqRnc60mWAT2iIYb0Qs6KEFs6XNWodJdNCBag6arRAmMTeYO68b7THi7QNuA71wnXCLZ3YTKxdyoRTe0TouqDWv7fRvSdinrcOKJqZwX1YynCQ_zgv_KoiqMgThJS93T3747_dvJ8Tl5dXJ-9NPrM-3pr_PhKDJH9MVhXvje87RcJ7AmFAfiC5ZCbWNbyppCvbSGGmq_k9dH51wnr4gS5Gydsc5m6QRbiKCLtls7dPNFwZVONy6vfKaBEntRyv-Md7HoYxjuGpFVLx_Vmjy4Qd5QucOGLdrOsWU3z3WlurX36DZv34HIbJlX19u27MSGc_NU-vM5VciqBc14KkaxHNy0FfV_gxfj3KV10IueJtaOw9dWedRW8e7UKqM6WuFruzxSu4zEVKcwhpbx767NTs5Ojt4d_5Wcf3h78rV9HvKM9MZxE9y_dT7An6-t80Vap3_n1nnF0uSSFdewyIm_WgJfZs4Z3HXOea1A-NouX6Bd1OKztWawl-Fm4TBqkHUu1NVKyncapEk2T4GI5_JasHbM1XgLsQ6lssJl8hm0xfrKw9W-Bvl-gy_C5LdWGGMdJIERFUnEyrCzXDBPt2GDrC4H155XvJNXuzARR8roMmQfq4I2eneperZcXNeIJTUCtIHa0mpQc303Fd7ZUK-4Nxjl92ANYp9G0SoXQ2CylbN3b85cJx9zhv7wiG3n7N8bjmNeMHJ2kaRpuZ11cD_W0NDHrKiSWYKW2y28-_fjDf3zJF5Ft1wiDcPWdxXDJVtO8Q4EOXLU3SHNoEWZRv5usMGMW4ZRUFNsduppirWhFOAuVXDb8ZVx_5FOr0DZD3pw5UGPHaNuEIHF413P2w28XWdv9MIcE2JFwQuBXTJ_uHlOxImKQGJxLUXZ47fGEv-fMRbXUDXjAoPkj348IW9Oz8lfTt-_eaXtDUOOd1wwrpZWDuB1xoviepdMVxUBvEgOPYtcXPMVQed0yvkFDEIy4wWJOStJxivCPiZlRSClYEuOAXvkLQhXMrKCj_JHzcEYzciUpfwK-hiZJVlMrha0WuMMbDAblox3KRAM8N7TDWbkbt2GEuh7TTJQiOUqVZGL0IXw_sI3vFpIoWGgiosLD_JDq5aZer-kVbRgMYpUaLlhTCxLU6EK7Gk6R7GukmpBsPeROJnNGIaSkgt2fcWLuNw72M8PtQopoY_oMwxr18_Z75XOaLwf1-8tPdg604Ee1w6qEBVT3j7_MbQlUhZJ41xcB0Y5rlGEkeUkaUhola3sgbZ0wRpFg5stXFyDVDawfeIEZZc2GY6B0jjqg4YtIUBTppsqL1POUDy6QSM2ha5m4G1Stm5pteyILWzx8CP0B-u61tu4enfgijt2aRJd3JmpfzcEMB-M-uwWtvJopzpuuEK8q2IVoaqs53Kcn89xuwrnLQJ_3-MJHNxTNMR6I67JYVEtU9l1vebtWStxURdoYxgNehYUd4Q1abpei3u28Hoedb9WM1PJcuFSPzQvF65-pwI7dg5BQ568I3iR7_m798d4kS9oC1cQB4aRCQTZAR2yZFJ1qKlIbt5d0WsCczsDvXFWwfdqlbH434FVIG4UU-XXV6cGbXhuPRX7WHZFQ4wvbWHc8_ySuERd_Jhj000UI5hOI-X8GA6B45-TJWo0sirS73_5DgEsAUG0JMo9ubFM86QU8EHeP8kt8B9OyyuaxjBtOrs-fAL49OEzgM_QcX757sXLb7_Za_XJ37795t909VwnhE5LsDArBoQEflwwgAnpO39Uj6j97OfeBY6Oerd8QsRX3DX67--dP76oHz9834NsL3S-Jf_np-QqPyETv3-e7gyCoivLDYCKAf2RGNIkWc4R0yX9qKJFJmTo5R8l4cLdU0NyFx6CvXqIyjzFPMlgfsA2oTEmiwcRbiDbeEJ--U428y_f2aENbfa_yaqYQIUJGThCCNGOdSgLCFenC-ork-6oZClWT3UGQ62S5ckNeCNe3E1UKWx39WU5WPaNXuDlsxD_5YZam4_xSKVtEngtXCKx_tJhHW1q16Iu09VcXNHkHTS4oqpPtDkWI9LcCFduNEPfEFwwZ5W1jGbpoLJpSVxc27PTs-0PfKPnviYe8OJMuTjqo1ltwoZIQ5Oj5SNpwlKnt8kayLi1XDBtXFwGHVma4AzW8l7XN1ww1jkNPnV6E52-WoE3ocHQA0htOHo2YGKRug1SXbRKNBeIXCKBMF2bThRkQn7E9FIbvW3SJgKOnadRF5nFVN2RyT1jL-Otb0km1olqfdHXfonGpGLFaqm3v66_NFlRq4tA5lY8hvV2yuNrXFwq2gtu7AUtEpY1eLjiVsIkC7eIOF6rQKjm4Xoyl7Njq2J5weQV28oHMhX_MMxY3Yprp2EjCc-qvKxUXCc3D_HPwxkYCKuCxaG4zFvRYNhJfb4fLSCh_wxrcxWn_tdnVLpjn0013AZdkValGcqSCm3XDb7eNqnV_Gp5UrYuGW8YHiabj5GvTKzsQnHqzYJEHK2PYb0c6shXnteZb_4F4nD-MA';
					
					
					if ( !function_exists( 'ts_cs_decode_string' ) ) {
						function ts_cs_decode_string( $string ) {
							
							// decode the encrypted theme opitons
							$options = unserialize( gzuncompress( stripslashes( call_user_func( 'base'. '64' .'_decode', rtrim( strtr( $string, '-_', '+/' ), '=' ) ) ) ) );
							
							// changing image path with client website url so image will be fetched from client server directly
							$demo_domains = array(
								'http://labtechco.themestekthemes.com/labtechco-data/',
								'http://labtechco.themestekthemes.com/demo1/',
								'http://labtechco.themestekthemes.com/demo2/',
								'http://labtechco.themestekthemes.com/',
							);
							
							// getting current site URL
							$current_url = get_site_url() . '/';
							
							foreach( $options as $key=>$val ){
								if( substr($val,0,7) == 'http://' ){
									$val = str_replace( $demo_domains, $current_url, $val );
									$options[$key] = $val;
								}
							}
							
							return $options;
						}
					}
					
					
					
					// Update theme options according to selected layout

					if( !empty($theme_options[$layout_type]) ){
						$new_options = ts_cs_decode_string( $theme_options[$layout_type] );
						update_option('labtechco_theme_options', $new_options);
					}
					
					
					/**** END CodeStart theme options import ****/
					
					
					
					
					
					/**** START - Edit "Hello World" post and change *****/
					$hello_world_post = get_post(1);
					if( !empty($hello_world_post) ){
						$newDate = array(
							'ID'		=> '1',
							'post_date'	=> "2014-12-10 0:0:0" // [ Y-m-d H:i:s ]
						);
						
						wp_update_post($newDate);
					}
					/**** END - Edit "Hello World" post and change *****/
					
					
					
					
				
			        // Import custom configuration
					$content = file_get_contents( THEMESTEK_LABTECHCO_DIR .'demo-content-setup/one-click-demo/'.$filename );
					
					if ( false !== strpos( $content, '<wp:theme_custom>' ) ) {
						preg_match('|<wp:theme_custom>(.*?)</wp:theme_custom>|is', $content, $config);
						if ($config && is_array($config) && count($config) > 1){
							$config = unserialize(base64_decode($config[1]));
							if (is_array($config)){
								$configs = array(
										'page_for_posts',
										'show_on_front',
										'page_on_front',
										'posts_per_page',
										'sidebars_widgets',
									);
								foreach ($configs as $item){
									if (isset($config[$item])){
										if( $item=='page_for_posts' || $item=='page_on_front' ){
											$page = get_page_by_title( $config[$item] );
											if( isset($page->ID) ){
												$config[$item] = $page->ID;
											}
										}
										update_option($item, $config[$item]);
									}
								}
								if (isset($config['sidebars_widgets'])){
									$sidebars = $config['sidebars_widgets'];
									update_option('sidebars_widgets', $sidebars);
									// read config
									$sidebars_config = array();
									if (isset($config['sidebars_config'])){
										$sidebars_config = $config['sidebars_config'];
										if (is_array($sidebars_config)){
											foreach ($sidebars_config as $name => $widget){
												update_option('widget_'.$name, $widget);
											}
										}
									}
								}
								
								if ( isset($config['menu_list']) && is_array($config['menu_list']) && count($config['menu_list'])>0 ){
									foreach( $config['menu_list'] as $location=>$menu_name ){
										$locations = get_theme_mod('nav_menu_locations'); // Get all menu Locations of current theme
										
										// Get menu name by id
										$term = get_term_by('name', $menu_name, 'nav_menu');
										$menu_id = $term->term_id;
										
										$locations[$location] = $menu_id;  //$foo is term_id of menu
										set_theme_mod('nav_menu_locations', $locations); // Set menu locations
									}
								}
								
							}
						}
					}
					
					
					// Overlay - change homepage slider
					if( !empty($layout_type) && $layout_type=='overlay' ){

						// Set homepage
						$front_page_id = get_page_by_title( 'Homepage-3' );
						update_option( 'show_on_front', 'page' );
						update_option( 'page_on_front', $front_page_id->ID );

					}
					
					
					
					
					// Infostack - Change Topbar right content and remove phone number area
					if( !empty($layout_type) && $layout_type=='infostack' ){
						
						// Set homepage
						$front_page_id = get_page_by_title( 'Homepage-2' );
						update_option( 'show_on_front', 'page' );
						update_option( 'page_on_front', $front_page_id->ID );
						
						// Topbar changes
						$theme_options = get_option('labtechco_theme_options');
						$theme_options['topbar_right_text'] = '[ts-social-links]';
						update_option('labtechco_theme_options', $theme_options);
					}
					
					
					
					
					
					// Update term count in admin section
					ts_update_term_count();
					flush_rewrite_rules(); // flush rewrite rule
					
					$answer['answer'] = 'finished';
					$answer['reload'] = 'yes';
					die( json_encode( $answer ) );
					
				break;
				
			}
			die;
		}
		
		
		
		/**
		 * Fetch and save image
		 **/
		function grab_image($url,$saveto){
			$ch = curl_init ($url);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_BINARYTRANSFER,1);
			$raw=curl_exec($ch);
			curl_close ($ch);
			if(file_exists($saveto)){
				unlink($saveto);
			}
			$fp = fopen($saveto,'x');
			fwrite($fp, $raw);
			fclose($fp);
		}



	} // END class

} // END if



if( !function_exists('ts_update_term_count') ){
function ts_update_term_count(){
	$get_taxonomies = get_taxonomies();
	foreach( $get_taxonomies as $taxonomy=>$taxonomy2 ){
		$terms = get_terms( $taxonomy, 'hide_empty=0' );
		$terms_array = array();
		foreach( $terms as $term ){
			$terms_array[] = $term->term_id;
		}
		if( !empty($terms_array) && count($terms_array)>0 ){
			$output = wp_update_term_count_now( $terms_array, $taxonomy );
		}
	}
}
}




// For AJAX callback
$themestek_labtechco_one_click_demo_setup = new themestek_labtechco_one_click_demo_setup;



