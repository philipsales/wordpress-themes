# :tada: Twemoji Awesome :beer:

Like [Font Awesome](http://fontawesome.io), but for [Twitter Emoji](http://twitter.github.io/twemoji/).

## [View Demo and Documentation &rarr;](http://ellekasai.github.io/twemoji-awesome)

## Author & License

Elle Kasai

- [Website](http://ellekasai.com/about)
- [Twitter](http://twitter.com/ellekasai)

Code: [MIT License](http://ellekasai.mit-license.org).
Graphics: [CC-BY](https://creativecommons.org/licenses/by/4.0/).
