<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.

/**
 *
 * Templates
 * @author ThemeStek
 * 
 */
class TS_labtechco_templates {
	public static function get( $n = 'x' ) {

		/* Set theme default color */
		$labtechco_theme_options = get_option('labtechco_theme_options');
		if ( ! empty( $labtechco_theme_options['skincolor'] ) ) {
			$color = $labtechco_theme_options['skincolor'];
		}else{
			$color = '#000000';
		}

		/* Set theme default Image & Video */
		$imgu = 'http://www.thememount.com/img/';
		$img = 'http://www.thememount.com/img/1000x1000.jpg';
		$vid = 'http://www.youtube.com/watch?v=AvWjf_RUy4c';


		$p = array(
				array(
					'section'	=> array('Service Box'),
					'name'		=> esc_attr('1.jpg'),
					'img'		=> '1.jpg',
					'content'	=> '[vc_row full_width="stretch_row"][vc_column width="1/3"][ts-heading h2="WHY CHOOSE <strong>OUR SERVICES</strong>"][/ts-heading][vc_column_text]We help interesting companies create industry products and services through long lasting relationships.[/vc_column_text][ts-btn title="VIEW ALL" shape="square"][/vc_column][vc_column width="2/3"][ts-servicebox h2="" boxstyle="style-2" show="2" column="two"][/ts-servicebox][/vc_column][/vc_row]',
					
				),
				array(
					'section'	=> array('Service Box'),
					'name'		=> esc_attr('2.jpg'),
					'img'		=> '2.jpg',
					'content'	=> '[vc_row full_width="stretch_row"][vc_column][ts-heading h2="RELIABLE &amp; HIGH-QUALITY
<strong> LABORATORY SERVICES</strong>" txt_align="center"][/ts-heading][vc_row_inner gap="15" el_class="ts-column-pad-0" ts_responsive_css="28029973|colbreak_no|||||||||colbreak_yes|||||||||colbreak_no||||||||||colbreak_no|||||||||"][vc_column_inner width="1/4"][ts-iconheadingbox boxstyle="style-1" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-flask" h2="LAB TECHNICIANS" show_btn="yes" btn_title="READ MORE" btn_add_icon="true"]Lorem Ipsum is simply dummy text of the printing and type settngdtry.[/ts-iconheadingbox][/vc_column_inner][vc_column_inner width="1/4"][ts-iconheadingbox boxstyle="style-1" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-microscope-2" h2="RESEARCH CENTER" show_btn="yes" btn_title="READ MORE" btn_add_icon="true"]Lorem Ipsum is simply dummy text of the printing and type settngdtry.[/ts-iconheadingbox][/vc_column_inner][vc_column_inner width="1/4"][ts-iconheadingbox boxstyle="style-1" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-beaker" h2="OUR EXPERIENCE" show_btn="yes" btn_title="READ MORE" btn_add_icon="true"]Lorem Ipsum is simply dummy text of the printing and type settngdtry.[/ts-iconheadingbox][/vc_column_inner][vc_column_inner width="1/4"][ts-iconheadingbox boxstyle="style-1" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-test-tube-1" h2="Helpful Test Tips" show_btn="yes" btn_title="READ MORE" btn_add_icon="true"]Lorem Ipsum is simply dummy text of the printing and type settngdtry.[/ts-iconheadingbox][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]',
					
				),
				array(
					'section'	=> array('Service Box'),
					'name'		=> esc_attr('3.jpg'),
					'img'		=> '3.jpg',
					'content'	=> '[vc_row full_width="stretch_row" css=".vc_custom_1533280258806{padding-top: 50px !important;padding-bottom: 40px !important;}"][vc_column width="1/3"][ts-iconheadingbox boxstyle="style-2" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-microscope-2" h2="Professional Team"]User can utilize his smartphone to pay for a wide range of services or any [/ts-iconheadingbox][/vc_column][vc_column width="1/3" ts_responsive_css="92097376|colbreak_no|||||||||colbreak_no|||||||||colbreak_no|50||50|||||||colbreak_no|||||||||"][ts-iconheadingbox boxstyle="style-2" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-suit" h2="Consultation"]User can utilize his smartphone to pay for a wide range of services or any [/ts-iconheadingbox][/vc_column][vc_column width="1/3"][ts-iconheadingbox boxstyle="style-2" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-flasks" h2="TREATMENT"]User can utilize his smartphone to pay for a wide range of services or any [/ts-iconheadingbox][/vc_column][/vc_row]',
					
				),
				array(
					'section'	=> array('Service Box', 'About'),
					'name'		=> esc_attr('4.jpg'),
					'img'		=> '4.jpg',
					'content'	=> '[vc_row full_width="stretch_row" equal_height="yes" css=".vc_custom_1527505460037{padding-top: 0px !important;padding-bottom: 0px !important;}"][vc_column ts_col_bg_expand="left" width="1/2" css=".vc_custom_1535362675993{background-image: url(http://labtechco.themestek.com/wp-content/uploads/2018/02/blog7.jpg?id=6936) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"][/vc_column][vc_column width="1/2" css=".vc_custom_1527761962656{padding-top: 80px !important;padding-bottom: 80px !important;padding-left: 80px !important;}" ts_responsive_css="82958560|colbreak_no|||||||||colbreak_no|||||40|40|40|40|colbreak_no|||||20||10|15||colbreak_no|||||||||"][ts-heading h2="EXPLORING ANATOMY &amp; PHYSIOLOGY <strong>IN THE LABORATORY</strong>"]I am promo text. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.[/ts-heading][vc_empty_space][vc_row_inner][vc_column_inner width="1/2"][ts-iconheadingbox boxstyle="style-2" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-bottle" h2="DEDICATED TEAM" h4="Aenean id mauris vulputat"]Lorem ipsum dolor sit amet cons Ectetur adipisicing elit.[/ts-iconheadingbox][/vc_column_inner][vc_column_inner width="1/2"][ts-iconheadingbox boxstyle="style-2" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-microscope-2" h2="BEST ENGINEERS" h4="Aenean id mauris vulputat"]Lorem ipsum dolor sit amet cons Ectetur adipisicing elit.[/ts-iconheadingbox][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]',
					
				),
				array(
					'section'	=> array('About'),
					'name'		=> esc_attr('5.jpg'),
					'img'		=> '5.jpg',
					'content'	=> '[vc_row ts_bgcolor="white" full_width="stretch_row" css=".vc_custom_1533382461252{padding-top: 30px !important;padding-bottom: 10px !important;}"][vc_column][ts-heading h2="WE ARE THE TRUSTED EXPERTS<br/><strong>WE KEEP THINGS SIMPLE</strong>" css=".vc_custom_1534658560222{margin-bottom: 25px !important;}"][/ts-heading][/vc_column][/vc_row]
[vc_row ts_bgcolor="white" full_width="stretch_row" equal_height="yes" css=".vc_custom_1535101048969{padding-top: 0px !important;}" ts_responsive_css="54267856|colbreak_no|||||||||colbreak_yes|||||||||colbreak_no||||||||||colbreak_no|||||||||"][vc_column ts_bgcolor="skincolor" ts_col_bg_expand="left" zindex="2" width="7/12" css=".vc_custom_1533272889888{padding-top: 60px !important;padding-right: 60px !important;padding-bottom: 40px !important;}"][vc_custom_heading text="Exerci tation ullamcorper suscipit lobortis" font_container="tag:h5|text_align:left|color:%23ffffff" use_theme_fonts="yes"][vc_column_text]Exerci tation ullamcorper suscipit lobortis nisl aliquip ex ea commodo non habent claritatem insitamconse quat duis autem Exerci tation.[/vc_column_text][vc_row_inner][vc_column_inner width="1/2"][ts-iconheadingbox boxstyle="style-5" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-statistics" h2="Extramural Funding" h4="Add link to heading."][/ts-iconheadingbox][ts-list icon_color="white" ts_textcolor="white" textsize="medium" icon_type="themify" icon_icon_themify="themifyicon ti-angle-right" line1="Qm9uZSUyMFNsaWNlcw==" line2="Q29ydGljb3N0ZXJvbmUlMjBFSUE=" line3="RGVudGluZSUyMERpc2Nz" line4="T3N0YXNlJUMyJUFFJTIwQkFQJTIwRUlB" line5="Q29tcCVDMiVBRSUyMEVMSVNBJTBB"][/vc_column_inner][vc_column_inner width="1/2"][ts-iconheadingbox boxstyle="style-5" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-test-tube-3" h2="Bacteria Markers" h4="Add link to heading."][/ts-iconheadingbox][ts-list icon_color="white" ts_textcolor="white" textsize="medium" icon_type="themify" icon_icon_themify="themifyicon ti-angle-right" line1="Qm9uZSUyMFNsaWNlcw==" line2="Q29ydGljb3N0ZXJvbmUlMjBFSUE=" line3="RGVudGluZSUyMERpc2Nz" line4="T3N0YXNlJUMyJUFFJTIwQkFQJTIwRUlB" line5="Q29tcCVDMiVBRSUyMEVMSVNBJTBB"][/vc_column_inner][/vc_row_inner][/vc_column][vc_column width="5/12" css=".vc_custom_1535101529856{margin-top: -130px !important;margin-left: -130px !important;padding-bottom: 540px !important;background-image: url(http://labtechco.themestek.com/wp-content/uploads/2018/08/img-01.jpg?id=6445) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}" ts_responsive_css="11632312|colbreak_no|0||||||||colbreak_no|||||||||colbreak_no||||||||||colbreak_no|||||||||"][/vc_column][/vc_row]',
					
				),
				array(
					'section'	=> array('Service Box'),
					'name'		=> esc_attr('6.jpg'),
					'img'		=> '6.jpg',
					'content'	=> '[vc_row full_width="stretch_row"][vc_column][ts-servicebox h2="EXPLORING ANATOMY &amp; PHYSIOLOGY<br/><strong>IN THE LABORATORY</strong>" boxstyle="style-2" show="6"][/ts-servicebox][/vc_column][/vc_row]',
					
				),
				array(
					'section'	=> array('Service Box'),
					'name'		=> esc_attr('7.jpg'),
					'img'		=> '7.jpg',
					'content'	=> '[vc_row full_width="stretch_row" css=".vc_custom_1533532192131{padding-top: 50px !important;}"][vc_column width="1/3"][ts-iconheadingbox boxstyle="style-4" i_type="fontawesome" h2="BLOOD BANK &amp; CHEMISTRY"]Laboratories used for scientific research take many forms because of the differing requirements of specialists.[/ts-iconheadingbox][/vc_column][vc_column width="1/3"][ts-iconheadingbox boxstyle="style-4" i_type="fontawesome" big_number_text="02" h2="COAGULATION &amp; CYTOLOGY"]Laboratories used for scientific research take many forms because of the differing requirements of specialists.[/ts-iconheadingbox][/vc_column][vc_column width="1/3"][ts-iconheadingbox boxstyle="style-4" i_type="fontawesome" big_number_text="03" h2="HEMATOLOGY &amp; HISTOLOGY"]Laboratories used for scientific research take many forms because of the differing requirements of specialists.[/ts-iconheadingbox][/vc_column][/vc_row]',
					
				),
				array(
					'section'	=> array('Service Box'),
					'name'		=> esc_attr('8.jpg'),
					'img'		=> '8.jpg',
					'content'	=> '[vc_row ts_bgcolor="grey" full_width="stretch_row" css=".vc_custom_1533285607880{padding-bottom: 100px !important;}"][vc_column][ts-heading h2="ABOUT US WE ARE <strong>THE
TRUSTED EXPERTS</strong>" txt_align="center"][/ts-heading][vc_row_inner][vc_column_inner width="1/3"][ts-iconheadingbox i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-microscope-2" h2="BLOOD BANK &amp; CHEMISTRY"]Laboratories used for scientific research nursing Implications.[/ts-iconheadingbox][/vc_column_inner][vc_column_inner width="1/3"][ts-iconheadingbox i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-bacteria" h2="COAGULATION &amp; CYTOLOGY"]Laboratories used for scientific research nursing Implications.
[/ts-iconheadingbox][/vc_column_inner][vc_column_inner width="1/3"][ts-iconheadingbox i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-flask" h2="Scientific research"]Laboratories used for scientific research nursing Implications.[/ts-iconheadingbox][/vc_column_inner][/vc_row_inner][/vc_column]',
					
				),
				array(
					'section'	=> array('Service Box','About'),
					'name'		=> esc_attr('9.jpg'),
					'img'		=> '9.jpg',
					'content'	=> '[vc_row][vc_column width="4/12"][ts-heading h2="WE PROVIDE BEST <strong>SERVICES FOR YOU</strong>"]
<div class="text">Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation.</div>
[/ts-heading][ts-btn title="READ MORE" shape="square" font_weight="no"][/vc_column][vc_column width="8/12"][vc_row_inner][vc_column_inner width="1/2" ts_responsive_css="79592734|colbreak_no|||||||||colbreak_no|||||||||colbreak_no|25|||||||||colbreak_no|||||||||"][ts-iconheadingbox boxstyle="style-2" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-microscope-2" h2="LAB TECHNICIANS" i_icon_tsoptmicon="tsoptmicon flaticon-filters" css=".vc_custom_1533545364186{margin-bottom: 40px !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"]Laboratories used for scientific research take many forms because of the differing requirements.[/ts-iconheadingbox][/vc_column_inner][vc_column_inner width="1/2"][ts-iconheadingbox boxstyle="style-2" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-test-tube-1" h2="RESEARCH CENTER" i_icon_tsoptmicon="tsoptmicon flaticon-filters" css=".vc_custom_1533545387823{margin-bottom: 0px !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"]Laboratories used for scientific research take many forms because of the differing requirements.[/ts-iconheadingbox][/vc_column_inner][/vc_row_inner][vc_row_inner css=".vc_custom_1527941023779{padding-top: 30px !important;}"][vc_column_inner width="1/2"][ts-iconheadingbox boxstyle="style-2" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-scientist" h2="HELPFUL TEST TIPS" i_icon_tsoptmicon="tsoptmicon flaticon-filters" css=".vc_custom_1533545412113{margin-bottom: 0px !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}" ts_responsive_css="36522654|colbreak_no|||||||||colbreak_no|||||||||colbreak_no||||||||||colbreak_no|||||||||"]Laboratories used for scientific research take many forms because of the differing requirements.[/ts-iconheadingbox][/vc_column_inner][vc_column_inner width="1/2" ts_responsive_css="97404923|colbreak_no|||||||||colbreak_no|||||||||colbreak_no|||||25|||||colbreak_no|||||||||"][ts-iconheadingbox boxstyle="style-2" i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-laboratory" h2="OUR EXPERT" i_icon_tsoptmicon="tsoptmicon flaticon-filters" css=".vc_custom_1533545598096{margin-bottom: 40px !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"]Laboratories used for scientific research take many forms because of the differing requirements.[/ts-iconheadingbox][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]',
					
				),
				array(
					'section'	=> array('Service Box'),
					'name'		=> esc_attr('10.jpg'),
					'img'		=> '10.jpg',
					'content'	=> '[vc_row full_width="stretch_row"][vc_column][ts-heading h2="EVALUATION OF THE CURRENT SAFETY
<strong>WE ARE THE TRUSTED EXPERTS</strong>" txt_align="center"][/ts-heading][vc_row_inner][vc_column_inner width="1/3"][ts-iconheadingbox i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-syringe" h2="Lab Technicians"]Lorem ipsum dolor sit amet,con sec tetur adipisicing elit,sed do.[/ts-iconheadingbox][/vc_column_inner][vc_column_inner width="1/3"][ts-iconheadingbox i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-scientist" h2="Research Center"]Lorem ipsum dolor sit amet,con sec tetur adipisicing elit,sed do.[/ts-iconheadingbox][/vc_column_inner][vc_column_inner width="1/3"][ts-iconheadingbox i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-laboratory" h2="OUR EXPERT"]Lorem ipsum dolor sit amet,con sec tetur adipisicing elit,sed do.[/ts-iconheadingbox][/vc_column_inner][/vc_row_inner][vc_row_inner][vc_column_inner width="1/3"][ts-iconheadingbox i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-test-tube-1" h2="Lab Technicians"]Lorem ipsum dolor sit amet,con sec tetur adipisicing elit,sed do.[/ts-iconheadingbox][/vc_column_inner][vc_column_inner width="1/3"][ts-iconheadingbox i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-science" h2="Research Center"]Lorem ipsum dolor sit amet,con sec tetur adipisicing elit,sed do.[/ts-iconheadingbox][/vc_column_inner][vc_column_inner width="1/3"][ts-iconheadingbox i_type="ts_labtechco_business_icon" i_icon_ts_labtechco_business_icon="ts-labtechco-business-icon ts-labtechco-business-icon-poison-1" h2="OUR EXPERT"]Lorem ipsum dolor sit amet,con sec tetur adipisicing elit,sed do.[/ts-iconheadingbox][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]',
					
				),
				array(
					'section'	=> array('Service Box'),
					'name'		=> esc_attr('11.jpg'),
					'img'		=> '11.jpg',
					'content'	=> '[vc_row ts_bgcolor="grey" full_width="stretch_row"][vc_column][ts-servicebox h2="EXPLORING ANATOMY &amp; PHYSIOLOGY<br/><strong>IN THE LABORATORY</strong>" boxstyle="style-1"][/ts-servicebox][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Team Member'),
					'name'		=> esc_attr('12.jpg'),
					'img'		=> '12.jpg',
					'content'	=> '[vc_row full_width="stretch_row"][vc_column][vc_row_inner][vc_column_inner width="1/3"][ts-heading h2="THE QUALIFIED &amp; <strong>SKILLFUL STAFF</strong>"][/ts-heading][/vc_column_inner][vc_column_inner width="2/3"][vc_column_text css=".vc_custom_1535353309371{margin-top: 30px !important;}"]Praesent molestie nec nisl eget scelerisque. Quisque placerat suscipit eros, eu tincidunt tellus blandit vel. Donec pellentesque dapibus interdum. Mauris et tellus congu.Praesent molestie nec nisl eget scelerisque. Quisque placerat suscipit eros, eu tincidunt tellus blandit vel.[/vc_column_text][/vc_column_inner][/vc_row_inner][ts-teambox h2="" txt_align="left" boxstyle="style-4" heading_style="horizontal"][/ts-teambox][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Team Member'),
					'name'		=> esc_attr('13.jpg'),
					'img'		=> '13.jpg',
					'content'	=> '[vc_row][vc_column width="1/3"][ts-heading h2="THE QUALIFIED &amp; <strong>SKILLFUL STAFF</strong>"][/ts-heading][vc_column_text]I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.[/vc_column_text][ts-btn title="VIEW ALL" style="outline" shape="square"][/vc_column][vc_column width="2/3"][ts-teambox h2="" boxstyle="style-4" show="-1" column="two" boxview="carousel" carousel_dots="1" carousel_nav="0"][/ts-teambox][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Team Member'),
					'name'		=> esc_attr('14.jpg'),
					'img'		=> '14.jpg',
					'content'	=> '[vc_row full_width="stretch_row"][vc_column][ts-teambox h2="EXPLORING ANATOMY &amp; PHYSIOLOGY <strong>IN THE LABORATORY</strong>" boxstyle="style-3" show="2" column="two"][/ts-teambox][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Team Member'),
					'name'		=> esc_attr('15.jpg'),
					'img'		=> '15.jpg',
					'content'	=> '[vc_row full_width="stretch_row"][vc_column][ts-teambox h2="EXPLORING ANATOMY &amp; PHYSIOLOGY <strong>IN THE LABORATORY</strong>"][/ts-teambox][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Team Member'),
					'name'		=> esc_attr('16.jpg'),
					'img'		=> '16.jpg',
					'content'	=> '[vc_row full_width="stretch_row"][vc_column][ts-teambox h2="EXPLORING ANATOMY &amp; PHYSIOLOGY <strong>IN THE LABORATORY</strong>" boxstyle="style-1" show="4" column="four"][/ts-teambox][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Testimonial'),
					'name'		=> esc_attr('17.jpg'),
					'img'		=> '17.jpg',
					'content'	=> '[vc_row ts_bgcolor="grey" full_width="stretch_row" css=".vc_custom_1533279094836{padding-bottom: 0px !important;}"][vc_column width="1/3" css=".vc_custom_1535114267793{margin-bottom: -100px !important;padding-right: 50px !important;}" ts_responsive_css="79509865|colbreak_no|||||||||colbreak_no|||0||||||colbreak_no||||||||||colbreak_no|||||||||"][vc_single_image image="7032" img_size="full"][/vc_column][vc_column width="2/3" ts_responsive_css="41936450|colbreak_no|||||||||colbreak_no|||||||||colbreak_no|||||||80|||colbreak_no|||||||||"][vc_row_inner][vc_column_inner width="2/3"][ts-heading h2="WHAT <strong>SPEAK PEOPLE</strong>"][/ts-heading][/vc_column_inner][vc_column_inner width="1/3"][ts-btn title="VIEW ALL" style="outline" shape="square" align="right" el_class="ts-btn-align-left-767"][/vc_column_inner][/vc_row_inner][ts-testimonialbox h2="" txt_align="left" boxstyle="style-1"][/ts-testimonialbox][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Testimonial'),
					'name'		=> esc_attr('18.jpg'),
					'img'		=> '18.jpg',
					'content'	=> '[vc_row full_width="stretch_row"][vc_column][ts-testimonialbox h2="WHAT <strong>SPEAK PEOPLE</strong>" show="-1" carousel_dots="1" carousel_nav="1" el_class="ts-boxes-carousel-arrows-left-both ts-boxes-carousel-dots-right"][/ts-testimonialbox][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Blog'),
					'name'		=> esc_attr('19.jpg'),
					'img'		=> '19.jpg',
					'content'	=> '[vc_row full_width="stretch_row"][vc_column][ts-blogbox h2="LATEST <strong>NEWS &amp; BLOGS</strong>" txt_align="left"][/ts-blogbox][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Testimonial'),
					'name'		=> esc_attr('20.jpg'),
					'img'		=> '20.jpg',
					'content'	=> '[vc_row ts_bgimage_position="left_bottom" full_width="stretch_row" css=".vc_custom_1535168420590{padding-top: 0px !important;padding-bottom: 0px !important;background-image: url(http://labtechco.themestek.com/wp-content/uploads/2018/08/ts-reaseachimage.png?id=7092) !important;background-position: 0 0 !important;background-repeat: no-repeat !important;}" ts_responsive_css="85601208|colbreak_no|||||||||colbreak_yes|||||||||colbreak_no||||||||||colbreak_no|||||||||"][vc_column width="1/2" css=".vc_custom_1534842278344{padding-top: 150px !important;padding-right: 20% !important;padding-bottom: 70px !important;}"][ts-heading h2="WE EMPLOY THE LATEST <strong>TECHNOLOGY &amp; COMPANY</strong>"][/ts-heading][vc_row_inner][vc_column_inner width="1/2"][ts-custom-heading text="Free Resources" font_container="tag:h6|text_align:left"][ts-custom-heading text="Bring to the table win-win survival strategies to ensure proactive domina." font_container="tag:p|font_size:14px|text_align:left|line_height:20px"][/vc_column_inner][vc_column_inner width="1/2"][ts-custom-heading text="Research Center" font_container="tag:h6|text_align:left"][ts-custom-heading text="Bring to the table win-win survival strategies to ensure proactive domina." font_container="tag:p|font_size:14px|text_align:left|line_height:20px"][/vc_column_inner][/vc_row_inner][ts-btn title="VIEW ALL" style="outline" shape="square" css=".vc_custom_1534830139525{margin-top: 20px !important;}"][/vc_column][vc_column ts_bgcolor="grey" ts_col_bg_expand="right" width="1/2" css=".vc_custom_1534842160047{padding-top: 150px !important;padding-bottom: 130px !important;}"][ts-testimonialbox h2="" boxstyle="style-3" css=".vc_custom_1535168978950{margin-left: -100px !important;}" el_class="ts-right-arrow ts-margin-left-0-991"][/ts-testimonialbox][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Blog'),
					'name'		=> esc_attr('21.jpg'),
					'img'		=> '21.jpg',
					'content'	=> '[vc_row ts_bgcolor="grey" full_width="stretch_row"][vc_column][ts-blogbox h2="WHAT GOING ON<br/><strong>IN OUR BLOG?</strong>" boxstyle="style-2" show="4" column="two" view="top-image"][/ts-blogbox][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Blog'),
					'name'		=> esc_attr('22.jpg'),
					'img'		=> '22.jpg',
					'content'	=> '[vc_row][vc_column width="1/3"][ts-heading h2="WHAT GOING ON <strong>IN OUR BLOG?</strong>"][/ts-heading][vc_column_text]It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.

Lab dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.[/vc_column_text][ts-btn title="VIEW ALL" style="outline" shape="square"][/vc_column][vc_column width="2/3"][ts-blogbox h2="" show="2" column="two" boxview="carousel" view="top-image"][/ts-blogbox][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Blog','Testimonial'),
					'name'		=> esc_attr('23.jpg'),
					'img'		=> '23.jpg',
					'content'	=> '[vc_row ts_bgcolor="grey" full_width="stretch_row"][vc_column width="1/2" css=".vc_custom_1525953377619{padding-right: 60px !important;}"][ts-blogbox h2="WHATS GOING ON <strong>IN OUR BLOG?</strong>" h2_font_container="font_size:36px|line_height:36px" txt_align="left" boxstyle="style-2" show="2" column="one" use_custom_fonts_h2="true" view="left-image"][/ts-blogbox][/vc_column][vc_column width="1/2"][ts-testimonialbox h2="WHAT <strong>SPEAK PEOPLE</strong>" txt_align="left" boxstyle="style-1" carousel_dots="1" carousel_nav="0"][/ts-testimonialbox][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Counter'),
					'name'		=> esc_attr('24.jpg'),
					'img'		=> '24.jpg',
					'content'	=> '[vc_row ts_bgimage_position="center_top" full_width="stretch_row" css=".vc_custom_1535348313958{background-image: url(http://labtechco.themestek.com/wp-content/uploads/2018/04/2.jpg?id=5692) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}" ts_responsive_css="23835983|colbreak_no|||||||||colbreak_yes|||||||||colbreak_no|||||||||900|colbreak_no|70||||||||"][vc_column width="6/12"][ts-heading h2="EVALUATION OF THE CURRENT SAFETY<strong> WE ARE THE TRUSTED EXPERTS</strong>" h4="WHY CHOOSE US"][/ts-heading][/vc_column][vc_column width="6/12"][vc_row_inner css=".vc_custom_1527054778594{margin-top: 50px !important;}" el_class="ts-colum-col-4-767"][vc_column_inner width="1/2" css=".vc_custom_1527054751035{padding-right: 25px !important;padding-left: 25px !important;}"][ts-facts-in-digits title="CLIENTS" digit="80" after="%"][/vc_column_inner][vc_column_inner width="1/2" css=".vc_custom_1527054757548{padding-right: 25px !important;padding-left: 25px !important;}"][ts-facts-in-digits title="MEMBERS" digit="65" after="%"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Counter'),
					'name'		=> esc_attr('25.jpg'),
					'img'		=> '25.jpg',
					'content'	=> '[vc_row ts_textcolor="white" ts_bgcolor="skincolor" full_width="stretch_row" gap="30"][vc_column width="1/4" css=".vc_custom_1527599589566{padding-right: 20px !important;padding-left: 20px !important;}"][ts-facts-in-digits boxstyle="style-2" title="PRODUCTION" digit="80" after="%" css=".vc_custom_1532061546963{padding-right: 20px !important;padding-left: 20px !important;}"][/vc_column][vc_column width="1/4"][ts-facts-in-digits boxstyle="style-2" title="RESEARCH" digit="75" after="%" css=".vc_custom_1535347698137{padding-right: 20px !important;padding-left: 20px !important;}"][/vc_column][vc_column width="1/4"][ts-facts-in-digits boxstyle="style-2" title="INTERNATIONAL" digit="60" after="%" css=".vc_custom_1532061561169{padding-right: 20px !important;padding-left: 20px !important;}"][/vc_column][vc_column width="1/4"][ts-facts-in-digits boxstyle="style-2" title="SATISFACTION" digit="95" after="%" css=".vc_custom_1532061568578{padding-right: 20px !important;padding-left: 20px !important;}"][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Counter'),
					'name'		=> esc_attr('26.jpg'),
					'img'		=> '26.jpg',
					'content'	=> '[vc_row ts_bgcolor="white" full_width="stretch_row"][vc_column][vc_row_inner el_class="ts-fid-sep"][vc_column_inner width="1/4"][ts-facts-in-digits boxstyle="style-3" title="Clients" digit="1000"][/vc_column_inner][vc_column_inner width="1/4"][ts-facts-in-digits boxstyle="style-3" title="Members" digit="302"][/vc_column_inner][vc_column_inner width="1/4"][ts-facts-in-digits boxstyle="style-3" title="YEARS OF EXPERIENCE" digit="50"][/vc_column_inner][vc_column_inner width="1/4"][ts-facts-in-digits boxstyle="style-3" title="Suppliers" digit="640"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('About'),
					'name'		=> esc_attr('27.jpg'),
					'img'		=> '27.jpg',
					'content'	=> '[vc_row css=".vc_custom_1535112354164{padding-top: 0px !important;padding-bottom: 0px !important;}"][vc_column][vc_separator][/vc_column][/vc_row][vc_row full_width="stretch_row" equal_height="yes" content_placement="middle" css=".vc_custom_1535167437172{padding-top: 0px !important;padding-bottom: 0px !important;}" ts_responsive_css="11734447|colbreak_no|||||||||colbreak_yes|||||||||colbreak_no||||||||||colbreak_no|||||||||"][vc_column width="7/12"][vc_single_image image="6534" img_size="full"][/vc_column][vc_column width="5/12" css=".vc_custom_1533211420868{padding-top: 90px !important;}"][ts-heading h2="LABORATORY PRIORITY <strong>SERVICES DELIVERED</strong>"]The concept behind this project was to create a mini website regarding mobile payment system[/ts-heading][vc_row_inner][vc_column_inner width="1/2"][ts-custom-heading text="ANALYZING" font_container="tag:h6|text_align:left"][vc_column_text]Lorem Ipsum is simply dummy text of the printing.[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2"][ts-custom-heading text="TESTING" font_container="tag:h6|text_align:left"][vc_column_text]Lorem Ipsum is simply dummy text of the printing.[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner][vc_column_inner width="1/2"][ts-custom-heading text="TREATMENT" font_container="tag:h6|text_align:left"][vc_column_text]Lorem Ipsum is simply dummy text of the printing.[/vc_column_text][/vc_column_inner][vc_column_inner width="1/2"][ts-custom-heading text="DIAGNOSTIC" font_container="tag:h6|text_align:left"][vc_column_text]Lorem Ipsum is simply dummy text of the printing.[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('CTA'),
					'name'		=> esc_attr('28.jpg'),
					'img'		=> '28.jpg',
					'content'	=> '[vc_row zindex="2" full_width="stretch_row" css=".vc_custom_1533382645261{padding-bottom: 30px !important;background-image: url(http://labtechco.themestek.com/wp-content/uploads/2018/08/bg-01.jpg?id=6464) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"][vc_column][vc_row_inner equal_height="yes"][vc_column_inner ts_bgcolor="skincolor" width="1/3" css=".vc_custom_1534658120477{margin-bottom: -80px !important;margin-left: 15px !important;padding-top: 40px !important;padding-right: 50px !important;padding-bottom: 40px !important;padding-left: 50px !important;}"][ts-custom-heading text="BEST LABORATORY AWARD WINNER YEAR 2016-2017" font_container="tag:h3|font_size:32px|text_align:left|color:%23ffffff|line_height:40px"][vc_column_text]Laboratories used for scientific research take many forms because of the differing requirements of specialists in the various fields of science and engineering. A physics laboratory.[/vc_column_text][ts-btn title="LEARN MORE" style="text" shape="square" color="white" font_weight="no" el_class="ts-link-button"][/vc_column_inner][vc_column_inner el_class="ts-play-text-box" width="2/3" ts_responsive_css="67081248|colbreak_no|||||||||colbreak_no|||||||||colbreak_no|||||250||120|||colbreak_no|||||||||"][ts-custom-heading text="PLAY" font_container="tag:p|font_size:14px|text_align:center|color:%23000000|line_height:14px" use_theme_fonts="no" google_fonts="font_family:Roboto%20Condensed%3A300%2C300italic%2Cregular%2Citalic%2C700%2C700italic|font_style:700%20bold%20regular%3A700%3Anormal" css=".vc_custom_1534584060736{background-color: #ffffff !important;}" el_class="ts-play-text-box" link="url:%23|||"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('CTA'),
					'name'		=> esc_attr('29.jpg'),
					'img'		=> '29.jpg',
					'content'	=> '[vc_row ts_bgcolor="skincolor" full_width="stretch_row" equal_height="yes" content_placement="middle" css=".vc_custom_1535347450006{padding-top: 80px !important;padding-bottom: 80px !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"][vc_column width="1/6"][/vc_column][vc_column width="2/3"][ts-heading h2="WE HAVE LOTS OF CASE STUDIES TO SHOW." h4="CHECK ALL CASE STUDIES" txt_align="center"][/ts-heading][ts-btn title="SEE NOW" shape="square" color="white" align="center"][/vc_column][vc_column width="1/6"][/vc_column][/vc_row]',
				), 
				array(
					'section'	=> array('Skill'),
					'name'		=> esc_attr('30.jpg'),
					'img'		=> '30.jpg',
					'content'	=> '[vc_row full_width="stretch_row" equal_height="yes" el_class="ts-overlap-row-section" ts_responsive_css="20731081|colbreak_no|||||||||colbreak_yes|||||||||colbreak_no||||||||||colbreak_no|||||||||"][vc_column width="1/2" ts_responsive_css="80226851|colbreak_no|||||||||colbreak_no||||||||30|colbreak_no||||||||15||colbreak_no|||||||||"][ts-heading h2="WE ARE TRUSTED BY <strong>WORLDS LEADING COMPANIES</strong>"][/ts-heading][vc_column_text]Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.[/vc_column_text][ts-progress-bar values="%5B%7B%22label%22%3A%22MEDICAL%20RESEARCH%22%2C%22value%22%3A%2290%22%2C%22add_icon%22%3A%22false%22%2C%22i_type%22%3A%22fontawesome%22%2C%22i_icon_fontawesome%22%3A%22fa%20fa-ok%22%2C%22i_icon_themify%22%3A%22ti-location-pin%22%2C%22i_icon_sgicon%22%3A%22sgicon%20sgicon-WorldWide%22%2C%22i_icon_vc_linecons%22%3A%22li_star%22%2C%22i_icon_ts_labtechco_business_icon%22%3A%22ts-labtechco-business-icon-ethanol%22%7D%2C%7B%22label%22%3A%22BIOTECHNOLOGY%22%2C%22value%22%3A%2280%22%2C%22add_icon%22%3A%22false%22%2C%22i_type%22%3A%22fontawesome%22%2C%22i_icon_fontawesome%22%3A%22fa%20fa-ok%22%2C%22i_icon_themify%22%3A%22ti-location-pin%22%2C%22i_icon_sgicon%22%3A%22sgicon%20sgicon-WorldWide%22%2C%22i_icon_vc_linecons%22%3A%22li_star%22%2C%22i_icon_ts_labtechco_business_icon%22%3A%22ts-labtechco-business-icon-ethanol%22%7D%5D" units="%"][/vc_column][vc_column width="1/2"][vc_single_image image="6638" img_size="full"][/vc_column][/vc_row]',
				), 
				array(
					'section'	=> array('Skill','Tab'),
					'name'		=> esc_attr('31.jpg'),
					'img'		=> '31.jpg',
					'content'	=> '[vc_row ts_bgcolor="white" full_width="stretch_row" css=".vc_custom_1529577478641{margin-top: -225px !important;padding-top: 200px !important;padding-bottom: 140px !important;}"][vc_column width="1/2"][ts-heading h2="WHAT<strong> WE ACHIEVED</strong>" h2_font_container="font_size:36px|line_height:36px" use_custom_fonts_h2="true" css=".vc_custom_1535345346048{margin-bottom: 70px !important;}"][/ts-heading][ts-progress-bar values="%5B%7B%22label%22%3A%22MEDICAL%20RESEARCH%22%2C%22value%22%3A%2290%22%2C%22add_icon%22%3A%22false%22%2C%22i_type%22%3A%22fontawesome%22%2C%22i_icon_fontawesome%22%3A%22fa%20fa-thumbs-o-up%22%2C%22i_icon_themify%22%3A%22themifyicon%20ti-thumb-up%22%2C%22i_icon_sgicon%22%3A%22sgicon%20sgicon-WorldWide%22%2C%22i_icon_vc_linecons%22%3A%22li_star%22%2C%22i_icon_ts_labtechco_business_icon%22%3A%22ts-labtechco-business-icon-nuclear%22%7D%2C%7B%22label%22%3A%22BIOTECHNOLOGY%22%2C%22value%22%3A%2260%22%2C%22add_icon%22%3A%22false%22%2C%22i_type%22%3A%22fontawesome%22%2C%22i_icon_fontawesome%22%3A%22fa%20fa-thumbs-o-up%22%2C%22i_icon_themify%22%3A%22themifyicon%20ti-thumb-up%22%2C%22i_icon_sgicon%22%3A%22sgicon%20sgicon-WorldWide%22%2C%22i_icon_vc_linecons%22%3A%22li_star%22%2C%22i_icon_ts_labtechco_business_icon%22%3A%22ts-labtechco-business-icon-nuclear%22%7D%2C%7B%22label%22%3A%22INTERNATIONAL%22%2C%22value%22%3A%2270%22%2C%22add_icon%22%3A%22false%22%2C%22i_type%22%3A%22fontawesome%22%2C%22i_icon_fontawesome%22%3A%22fa%20fa-thumbs-o-up%22%2C%22i_icon_themify%22%3A%22themifyicon%20ti-thumb-up%22%2C%22i_icon_sgicon%22%3A%22sgicon%20sgicon-WorldWide%22%2C%22i_icon_vc_linecons%22%3A%22li_star%22%2C%22i_icon_ts_labtechco_business_icon%22%3A%22ts-labtechco-business-icon-nuclear%22%7D%2C%7B%22label%22%3A%22SATISFACTION%22%2C%22value%22%3A%2299%22%2C%22add_icon%22%3A%22false%22%2C%22i_type%22%3A%22fontawesome%22%2C%22i_icon_fontawesome%22%3A%22fa%20fa-thumbs-o-up%22%2C%22i_icon_themify%22%3A%22themifyicon%20ti-thumb-up%22%2C%22i_icon_sgicon%22%3A%22sgicon%20sgicon-WorldWide%22%2C%22i_icon_vc_linecons%22%3A%22li_star%22%2C%22i_icon_ts_labtechco_business_icon%22%3A%22ts-labtechco-business-icon-nuclear%22%7D%5D" units="%"][/vc_column][vc_column width="1/2"][ts-heading h2="WHY CHOOSE <strong>US</strong>"][/ts-heading][vc_tta_tabs style="outline" shape="square" active_section="1"][vc_tta_section title="Our Mission" tab_id="1527857724072-82c5db33-4dfce536-cc3aa408-9ba9"][vc_column_text css=".vc_custom_1535345417841{margin-bottom: 0px !important;}"]Sapiente accusamus repudiandae architecto corporis aspernatur. Eligendi, accusamus quas mollitia. Obcaecati nam provident molestias aut aperiam qui ut similique odit natus nihil.

Accusamus repudiandae architecto corporis aspernatur. Eligendi, accusamus quas mollitia. Obcaecati nam provident molestias aut aperiam qui ut similique odit natus nihil.[/vc_column_text][/vc_tta_section][vc_tta_section title="Our Vision" tab_id="1527857724607-19059654-b304e536-cc3aa408-9ba9"][vc_column_text css=".vc_custom_1535345427898{margin-bottom: 0px !important;}"]Sapiente accusamus repudiandae architecto corporis aspernatur. Eligendi, accusamus quas mollitia. Obcaecati nam provident molestias aut aperiam qui ut similique odit natus nihil.

Accusamus repudiandae architecto corporis aspernatur. Eligendi, accusamus quas mollitia. Obcaecati nam provident molestias aut aperiam qui ut similique odit natus nihil.[/vc_column_text][/vc_tta_section][vc_tta_section title="Our Values" tab_id="1527857725067-5be607d0-641ce536-cc3aa408-9ba9"][vc_column_text css=".vc_custom_1535345434914{margin-bottom: 0px !important;}"]Sapiente accusamus repudiandae architecto corporis aspernatur. Eligendi, accusamus quas mollitia. Obcaecati nam provident molestias aut aperiam qui ut similique odit natus nihil.

Accusamus repudiandae architecto corporis aspernatur. Eligendi, accusamus quas mollitia. Obcaecati nam provident molestias aut aperiam qui ut similique odit natus nihil.[/vc_column_text][/vc_tta_section][/vc_tta_tabs][/vc_column][/vc_row]',
				), 
				array(
					'section'	=> array('According'),
					'name'		=> esc_attr('32.jpg'),
					'img'		=> '32.jpg',
					'content'	=> '[vc_row full_width="stretch_row" equal_height="yes" css=".vc_custom_1535344664641{padding-top: 0px !important;padding-bottom: 0px !important;}"][vc_column ts_col_bg_expand="left" width="1/2" el_class="ts-man-colum" css=".vc_custom_1535344719236{background-image: url(http://labtechco.themestek.com/wp-content/uploads/2018/01/blog-01.jpg?id=6984) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"][/vc_column][vc_column width="1/2" css=".vc_custom_1535344731597{padding-top: 80px !important;padding-bottom: 80px !important;padding-left: 60px !important;}"][ts-heading h2="WERE LOCAL JUST LIKE YOU <strong>WE GOOD WORK MEANS.</strong>" css=".vc_custom_1535344786684{margin-bottom: 25px !important;}"][/ts-heading][vc_tta_accordion shape="square" active_section="1"][vc_tta_section title="WE ARE PROFESSIONAL" tab_id="1530704872888-31a97ecb-9456718c-1ca6"][vc_row_inner][vc_column_inner width="1/6"][vc_single_image image="7163" img_size="80*70" css=".vc_custom_1535344612636{margin-bottom: 0px !important;}"][/vc_column_inner][vc_column_inner width="5/6" css=".vc_custom_1530706477141{margin-top: 15px !important;}"][vc_column_text css=".vc_custom_1530706394470{margin-bottom: 0px !important;}"]Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][vc_tta_section title="WE ARE TRUSTED" tab_id="1530704872938-3e34e67f-1b36718c-1ca6"][vc_row_inner][vc_column_inner][vc_column_text css=".vc_custom_1530706394470{margin-bottom: 0px !important;}"]Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][vc_tta_section title="WE ARE EXPERT" tab_id="1530706034736-cbe71437-2fa7718c-1ca6"][vc_row_inner][vc_column_inner][vc_column_text css=".vc_custom_1530706394470{margin-bottom: 0px !important;}"]Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][/vc_tta_accordion][/vc_column][/vc_row]',
				), 
				array(
					'section'	=> array('According'),
					'name'		=> esc_attr('33.jpg'),
					'img'		=> '33.jpg',
					'content'	=> '[vc_row ts_bgcolor="grey" full_width="stretch_row"][vc_column width="1/2" css=".vc_custom_1525953377619{padding-right: 60px !important;}"][ts-blogbox h2="WHATS GOING ON <strong>IN OUR BLOG?</strong>" h2_font_container="font_size:36px|line_height:36px" txt_align="left" boxstyle="style-2" show="2" column="one" use_custom_fonts_h2="true" view="left-image"][/ts-blogbox][/vc_column][vc_column width="1/2"][ts-heading h2="FEEL FREE <strong>FOR ANY FAQS</strong>" h2_font_container="font_size:36px|line_height:36px" use_custom_fonts_h2="true" el_class="ts-capitalize"][/ts-heading][vc_tta_accordion shape="square" color="white" c_icon="chevron" c_position="right" active_section="1"][vc_tta_section title="WE ARE PROFESSIONAL" tab_id="1524995204671-cf960c4e-aaafcbff-7f1037bb-d372"][vc_row_inner css=".vc_custom_1524999062760{margin-top: 5px !important;margin-right: 0px !important;margin-left: 0px !important;}"][vc_column_inner width="2/12" css=".vc_custom_1524998704455{padding-right: 0px !important;padding-left: 0px !important;}"][vc_single_image image="7163" img_size="80*70" css=".vc_custom_1535344340826{margin-bottom: 0px !important;}"][/vc_column_inner][vc_column_inner width="10/12"][vc_column_text css=".vc_custom_1524998932658{margin-bottom: 0px !important;}"]Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][vc_tta_section title="WE ARE TRUSTED" tab_id="1524999111324-29a4ff78-d512cbff-7f1037bb-d372"][vc_row_inner css=".vc_custom_1524999062760{margin-top: 5px !important;margin-right: 0px !important;margin-left: 0px !important;}"][vc_column_inner css=".vc_custom_1524998704455{padding-right: 0px !important;padding-left: 0px !important;}"][vc_column_text css=".vc_custom_1524998932658{margin-bottom: 0px !important;}"]Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][vc_tta_section title="WE ARE EXPERT" tab_id="1524995204722-f37e246a-0405cbff-7f1037bb-d372"][vc_row_inner css=".vc_custom_1524999062760{margin-top: 5px !important;margin-right: 0px !important;margin-left: 0px !important;}"][vc_column_inner css=".vc_custom_1524998704455{padding-right: 0px !important;padding-left: 0px !important;}"][vc_column_text css=".vc_custom_1524998932658{margin-bottom: 0px !important;}"]Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][vc_tta_section title="WE ARE PROFESSIONAL" tab_id="1524999190970-2827e4ac-6ba9cbff-7f1037bb-d372"][vc_row_inner css=".vc_custom_1524999062760{margin-top: 5px !important;margin-right: 0px !important;margin-left: 0px !important;}"][vc_column_inner css=".vc_custom_1524998704455{padding-right: 0px !important;padding-left: 0px !important;}"][vc_column_text css=".vc_custom_1524998932658{margin-bottom: 0px !important;}"]Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][/vc_tta_accordion][/vc_column][/vc_row]',
				), 
				array(
					'section'	=> array('According'),
					'name'		=> esc_attr('34.jpg'),
					'img'		=> '34.jpg',
					'content'	=> '[vc_row full_width="stretch_row" css=".vc_custom_1530956208911{background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"][vc_column width="1/2"][ts-heading h2="WE GOOD <strong>WORK MEANS</strong>" h2_font_container="font_size:36px|line_height:36px" use_custom_fonts_h2="true"][/ts-heading][vc_tta_accordion active_section="1"][vc_tta_section title="WE ARE PROFESSIONAL" tab_id="1527596423745-c7db957c-54ebd894-280ecb4c-623c"][vc_row_inner][vc_column_inner width="1/4"][vc_single_image image="7163"][/vc_column_inner][vc_column_inner width="3/4"][vc_column_text]Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][vc_tta_section title="WE ARE TRUSTED" tab_id="1527596423764-dec95ff5-e879d894-280ecb4c-623c"][vc_row_inner][vc_column_inner][vc_column_text]Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][vc_tta_section title="WE ARE EXPERT" tab_id="1527596939941-cbd5fbfa-2e13d894-280ecb4c-623c"][vc_row_inner][vc_column_inner][vc_column_text]Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_tta_section][/vc_tta_accordion][/vc_column][vc_column width="1/2"][ts-heading h2="CHECK OUT <strong>OUR BUILDINGS</strong>" h2_font_container="font_size:36px|line_height:36px" use_custom_fonts_h2="true"]Pleasure and praising pain was born and will give you complete works of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness explain too.[/ts-heading][vc_column_text]you this mistaken praising pain was born and will give you a complete account.Suspendisse ullamcorper metus in erat viverra , vehicula pharetra dolor accumsan. In arcu ex, rutrum finibus malesuada vel.Praesent pharetra orci odio, ut mattis tellus ullamcorper ornare.[/vc_column_text][ts-btn title="JOIN US NOW" style="outline" shape="square"][/vc_column][/vc_row]',
				), 
				array(
					'section'	=> array('Client'),
					'name'		=> esc_attr('35.jpg'),
					'img'		=> '35.jpg',
					'content'	=> '[vc_row][vc_column][ts-clientsbox h2="" boxstyle="style-1" column="six" boxview="default"][/ts-clientsbox][/vc_column][/vc_row]',
				), 
				array(
					'section'	=> array('About','Skill'),
					'name'		=> esc_attr('36.jpg'),
					'img'		=> '36.jpg',
					'content'	=> '[vc_row full_width="stretch_row" parallax="content-moving" css=".vc_custom_1534658782004{background-image: url(http://labtechco.themestek.com/wp-content/uploads/2018/02/blog.jpg?id=6938) !important;background-position: center;background-repeat: no-repeat !important;background-size: cover !important;}"][vc_column ts_bgcolor="white" width="1/3" css=".vc_custom_1533213160370{padding-top: 40px !important;padding-right: 40px !important;padding-bottom: 40px !important;padding-left: 40px !important;}"][ts-custom-heading text="BEST LABORATORY AWARD WINNER YEAR" font_container="tag:h4|font_size:32px|text_align:left|line_height:40px"][vc_column_text]We are integrated engineering company composed exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequaturUt enim[/vc_column_text][ts-progress-bar values="%5B%7B%22label%22%3A%22PROFESSIONAL%20%22%2C%22value%22%3A%2290%22%2C%22add_icon%22%3A%22false%22%2C%22i_type%22%3A%22fontawesome%22%2C%22i_icon_fontawesome%22%3A%22fa%20fa-ok%22%2C%22i_icon_themify%22%3A%22ti-location-pin%22%2C%22i_icon_sgicon%22%3A%22sgicon%20sgicon-WorldWide%22%2C%22i_icon_vc_linecons%22%3A%22li_star%22%2C%22i_icon_ts_labtechco_business_icon%22%3A%22ts-labtechco-business-icon-ethanol%22%7D%2C%7B%22label%22%3A%22ANALYZING%22%2C%22value%22%3A%2280%22%2C%22add_icon%22%3A%22false%22%2C%22i_type%22%3A%22fontawesome%22%2C%22i_icon_fontawesome%22%3A%22fa%20fa-ok%22%2C%22i_icon_themify%22%3A%22ti-location-pin%22%2C%22i_icon_sgicon%22%3A%22sgicon%20sgicon-WorldWide%22%2C%22i_icon_vc_linecons%22%3A%22li_star%22%2C%22i_icon_ts_labtechco_business_icon%22%3A%22ts-labtechco-business-icon-ethanol%22%7D%5D" units="%"][/vc_column][vc_column width="2/3"][/vc_column][/vc_row]',
				), 
				array(
					'section'	=> array('About'),
					'name'		=> esc_attr('37.jpg'),
					'img'		=> '37.jpg',
					'content'	=> '[vc_row equal_height="yes" css=".vc_custom_1535112868661{padding-bottom: 130px !important;}" ts_responsive_css="32388294|colbreak_no|||||||||colbreak_yes|||||||||colbreak_no||||||||||colbreak_no|||||||||"][vc_column width="7/12" css=".vc_custom_1533205805036{padding-right: 25% !important;}"][ts-heading h2="WE EMPLOY THE LATEST <strong>TECHNOLOGY &amp; COMPANY</strong>" css=".vc_custom_1534590104536{margin-bottom: 0px !important;}"]Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.[/ts-heading][vc_row_inner][vc_column_inner width="1/2"][ts-list icon_icon_fontawesome="fa fa-chevron-right" line1="Qm9uZSUyMFNsaWNlcw==" line2="Q29ydGljb3N0ZXJvbmUlMjBFSUE=" line3="RGVudGluZSUyMERpc2Nz" line4="UmF0JTJGTW91c2UlMjBQSU5QJTIwRUlB"][/vc_column_inner][vc_column_inner width="1/2"][ts-list icon_icon_fontawesome="fa fa-chevron-right" line1="Qm9uZSUyMFNsaWNlcw==" line2="Q29ydGljb3N0ZXJvbmUlMjBFSUE=" line3="RGVudGluZSUyMERpc2Nz" line4="UmF0JTJGTW91c2UlMjBQSU5QJTIwRUlB"][/vc_column_inner][/vc_row_inner][ts-btn title="VIEW All" style="outline" shape="square" css=".vc_custom_1534590093554{margin-top: 35px !important;}"][/vc_column][vc_column ts_col_bg_expand="right" width="5/12" css=".vc_custom_1535113204009{padding-bottom: 465px !important;background-image: url(http://labtechco.themestek.com/wp-content/uploads/2018/08/bg-03.jpg?id=6492) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}" ts_responsive_css="80189506|colbreak_no|||||||||colbreak_no|50||||||||colbreak_no||||||||||colbreak_no|||||||||"][vc_single_image image="6479" img_size="full" el_class="ts-abs-img ts-hide-991"][/vc_column][/vc_row]',
				), 
				array(
					'section'	=> array('About','Counter'),
					'name'		=> esc_attr('38.jpg'),
					'img'		=> '38.jpg',
					'content'	=> '[vc_row ts_bgcolor="white" full_width="stretch_row"][vc_column width="1/2"][vc_single_image image="6445" img_size="full"][/vc_column][vc_column width="1/2" css=".vc_custom_1535349437249{padding-top: 60px !important;}"][ts-heading h2="ABOUT US WE ARE <strong>THE TRUSTED<br />EXPERTS TEAM</strong>"]We appreciate your trust and hope that you find our services helpful Enter text for subheading line.[/ts-heading][vc_column_text]Laboratories used for scientific research take many forms because of the differing requirements of specialists in the various fields of science and engineering.</p>
<p>Exerci tation ullamcorper suscipit lobortis nisl aliquip ex ea commodo non habent claritatem insitamconse quat duis autem Exerci tation.<br />
[/vc_column_text][vc_row_inner el_class="ts-fid-sep"][vc_column_inner width="1/3"][ts-facts-in-digits boxstyle="style-3" title="Clients" digit="1000"][/vc_column_inner][vc_column_inner width="1/3"][ts-facts-in-digits boxstyle="style-3" title="Members" digit="302"][/vc_column_inner][vc_column_inner width="1/3"][ts-facts-in-digits boxstyle="style-3" title="EXPERIENCE" digit="50"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]',
				), 
				array(
					'section'	=> array('About'),
					'name'		=> esc_attr('39.jpg'),
					'img'		=> '39.jpg',
					'content'	=> '[vc_row ts_bgimage_position="right_bottom" full_width="stretch_row" css=".vc_custom_1535365659419{padding-bottom: 0px !important;background-image: url(http://labtechco.themestek.com/wp-content/uploads/2018/06/bg-01.png?id=5395) !important;background-position: 0 0 !important;background-repeat: no-repeat !important;}"][vc_column width="7/12"][ts-heading h2="WERE LOCAL JUST LIKE YOU WE<br/><strong>GOOD WORK MEANS.</strong>"][/ts-heading][vc_column_text]We are integrated engineering company composed exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequaturUt enim ad minima veniam, quis nostrum exercitationem ullam. corporis suscipit laboriosam nisi ut aliquid.[/vc_column_text][vc_row_inner][vc_column_inner width="1/2"][ts-list textsize="medium" icon_icon_fontawesome="fa fa-arrow-circle-o-right" line1="Q29ydGljb3N0ZXJvbmUlMjBFSUElMEE=" line2="RGVudGluZSUyMERpc2Nz" line3="UmF0JTJGTW91c2UlMjBQSU5QJTIwRUlB" line4="Qm9uZSUyMFNsaWNlcw=="][/vc_column_inner][vc_column_inner width="1/2"][ts-list textsize="medium" icon_icon_fontawesome="fa fa-arrow-circle-o-right" line1="Q29ydGljb3N0ZXJvbmUlMjBFSUElMEE=" line2="RGVudGluZSUyMERpc2Nz" line3="UmF0JTJGTW91c2UlMjBQSU5QJTIwRUlB" line4="Qm9uZSUyMFNsaWNlcw=="][/vc_column_inner][/vc_row_inner][/vc_column][vc_column width="5/12"][ts-single-image image="http://labtechco.themestek.com/wp-content/uploads/2018/08/img-03.png|http://labtechco.themestek.com/wp-content/uploads/2018/08/img-03-150x150.png|6479"][/vc_column][/vc_row]',
				), 
				array(
					'section'	=> array('About'),
					'name'		=> esc_attr('40.jpg'),
					'img'		=> '40.jpg',
					'content'	=> '[vc_row full_width="stretch_row"][vc_column width="1/2"][ts-single-image image="http://labtechco.themestek.com/wp-content/uploads/2018/02/blog6.jpg|http://labtechco.themestek.com/wp-content/uploads/2018/02/blog6-150x150.jpg|6935"][/vc_column][vc_column width="1/2" css=".vc_custom_1532004486292{margin-top: 0px !important;}"][ts-heading h2="WERE LOCAL JUST LIKE<br />
<strong>YOU WE GOOD WORK</strong>"][/ts-heading][vc_column_text]<br />
The best for less, just care them Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque ut maximus orci. Curabitur feugiat scelerisque bibendum.</p>
<p>Cras auctor scelerisque metus quis lobortis. Donec ut imperdiet diam.I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.[/vc_column_text][vc_row_inner][vc_column_inner width="1/3"][ts-btn title="READMORE" shape="square"][/vc_column_inner][vc_column_inner width="1/3"][ts-btn title="CONTACT" style="outline" shape="square"][/vc_column_inner][vc_column_inner width="1/3"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('Service Box'),
					'name'		=> esc_attr('41.jpg'),
					'img'		=> '41.jpg',
					'content'	=> '[vc_row full_width="stretch_row_content_no_spaces" css=".vc_custom_1535362248097{padding-top: 0px !important;padding-bottom: 0px !important;}"][vc_column][ts-servicebox h2="" boxstyle="style-2" box_spacing="0px" show="5" column="five"][/ts-servicebox][/vc_column][/vc_row]',
					
				),  
				array(
					'section'	=> array('Research'),
					'name'		=> esc_attr('42.jpg'),
					'img'		=> '42.jpg',
					'content'	=> '[vc_row full_width="stretch_row_content_no_spaces"][vc_column][ts-portfoliobox h2="CHECK OUR
<strong>LATEST CASE STUDIES</strong>" boxstyle="style-2" box_spacing="0px" show="5" column="four" boxview="carousel" carousel_nav="0"][/ts-portfoliobox][/vc_column][/vc_row]',
				), 
				array(
					'section'	=> array('Tab'),
					'name'		=> esc_attr('43.jpg'),
					'img'		=> '43.jpg',
					'content'	=> '[vc_row full_width="stretch_row" css=".vc_custom_1531999035927{background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"][vc_column width="1/2"][ts-heading h2="WHY CHOOSE <strong>US</strong>"][/ts-heading][vc_tta_tabs style="outline" shape="square" active_section="1"][vc_tta_section title="Our Mission" tab_id="1527857724072-82c5db33-4dfce536-cc3aa408-9ba9"][vc_column_text css=".vc_custom_1535345417841{margin-bottom: 0px !important;}"]Sapiente accusamus repudiandae architecto corporis aspernatur. Eligendi, accusamus quas mollitia. Obcaecati nam provident molestias aut aperiam qui ut similique odit natus nihil.

Accusamus repudiandae architecto corporis aspernatur. Eligendi, accusamus quas mollitia. Obcaecati nam provident molestias aut aperiam qui ut similique odit natus nihil.[/vc_column_text][/vc_tta_section][vc_tta_section title="Our Vision" tab_id="1527857724607-19059654-b304e536-cc3aa408-9ba9"][vc_column_text css=".vc_custom_1535345427898{margin-bottom: 0px !important;}"]Sapiente accusamus repudiandae architecto corporis aspernatur. Eligendi, accusamus quas mollitia. Obcaecati nam provident molestias aut aperiam qui ut similique odit natus nihil.

Accusamus repudiandae architecto corporis aspernatur. Eligendi, accusamus quas mollitia. Obcaecati nam provident molestias aut aperiam qui ut similique odit natus nihil.[/vc_column_text][/vc_tta_section][vc_tta_section title="Our Values" tab_id="1527857725067-5be607d0-641ce536-cc3aa408-9ba9"][vc_column_text css=".vc_custom_1535345434914{margin-bottom: 0px !important;}"]Sapiente accusamus repudiandae architecto corporis aspernatur. Eligendi, accusamus quas mollitia. Obcaecati nam provident molestias aut aperiam qui ut similique odit natus nihil.

Accusamus repudiandae architecto corporis aspernatur. Eligendi, accusamus quas mollitia. Obcaecati nam provident molestias aut aperiam qui ut similique odit natus nihil.[/vc_column_text][/vc_tta_section][/vc_tta_tabs][/vc_column][vc_column width="1/2"][vc_single_image image="6926" img_size="large"][/vc_column][/vc_row]',					
				),
				array(
					'section'	=> array('Testimonial','Client'),
					'name'		=> esc_attr('44.jpg'),
					'img'		=> '44.jpg',
					'content'	=> '[vc_row][vc_column width="1/2" css=".vc_custom_1527938681425{padding-right: 30px !important;}"][ts-heading h2="WHAT OUR <strong>CLIENT’S TALKING ?</strong>" h2_font_container="font_size:36px|line_height:36px" use_custom_fonts_h2="true"][/ts-heading][ts-testimonialbox h2="" boxstyle="style-1" carousel_dots="1" carousel_nav="0" el_class="ts-arrow-right"][/ts-testimonialbox][/vc_column][vc_column width="1/2"][ts-heading h2="OUR BUSINESS <strong>PARTNERSHIP</strong>" h2_font_container="font_size:36px|line_height:36px" use_custom_fonts_h2="true"][/ts-heading][ts-clientsbox h2="" boxstyle="style-2" show="6" column="three" boxview="default"][/ts-clientsbox][/vc_column][/vc_row]',					
				),  
				array(
					'section'	=> array('Research'),
					'name'		=> esc_attr('45.jpg'),
					'img'		=> '45.jpg',
					'content'	=> '[vc_row ts_bgcolor="skincolor" full_width="stretch_row" css=".vc_custom_1535342619594{padding-bottom: 30px !important;}"][vc_column][vc_row_inner content_placement="bottom"][vc_column_inner width="7/12" offset="vc_col-lg-7"][ts-heading h2="CHECK OUR<br/><strong>LATEST CASE STUDIES</strong>"][/ts-heading][/vc_column_inner][vc_column_inner width="5/12" offset="vc_col-lg-5"][vc_column_text]This is Photoshops version of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor.[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row ts_bgcolor="darkgrey" full_width="stretch_row_content_no_spaces" css=".vc_custom_1529500426032{padding-top: 0px !important;padding-bottom: 0px !important;}"][vc_column][ts-portfoliobox h2="" boxstyle="style-2" box_spacing="0px" show="6" column="four" boxview="carousel" carousel_nav="0"][/ts-portfoliobox][/vc_column][/vc_row]',					
				), 
				array(
					'section'	=> array('Research'),
					'name'		=> esc_attr('46.jpg'),
					'img'		=> '46.jpg',
					'content'	=> '[vc_row full_width="stretch_row"][vc_column][ts-portfoliobox h2="CHECK OUR<br/><strong>LATEST CASE STUDIES</strong>" boxstyle="style-2" show="6"][/ts-portfoliobox][/vc_column][/vc_row]',	
				),
				array(
					'section'	=> array('About'),
					'name'		=> esc_attr('47.jpg'),
					'img'		=> '47.jpg',
					'content'	=> '[vc_row full_width="stretch_row" el_class="ts-column-pad-0" css=".vc_custom_1535171682818{padding-bottom: 50px !important;}" ts_responsive_css="69022376|colbreak_yes|||||||||colbreak_no|||||||||colbreak_no||||||||||colbreak_no|||||||||"][vc_column width="1/2" css=".vc_custom_1533536933706{padding-right: 15% !important;}"][ts-heading h2="ABOUT US WE ARE <strong>THE<br />
TRUSTED EXPERTS</strong>" css=".vc_custom_1534659576627{margin-bottom: 10px !important;}"]Laboratories used for scientific research take many forms because of the differing requirements of specialists.[/ts-heading][vc_column_text]Laboratories used for scientific research take many forms because of the differing requirements of specialists in the various fields of science and engineering.[/vc_column_text][ts-btn title="READ MORE" style="outline" shape="square"][/vc_column][vc_column ts_bgcolor="skincolor" width="1/2"][vc_single_image image="6380" img_size="full"][vc_row_inner css=".vc_custom_1534659427495{padding-right: 50px !important;padding-bottom: 10px !important;padding-left: 50px !important;}"][vc_column_inner width="1/2"][ts-custom-heading text="HOURS &amp; PRICING" font_container="tag:h4|text_align:left"][ts-custom-heading text="We look forward to seeing you!" font_container="tag:p|text_align:left"][/vc_column_inner][vc_column_inner width="1/2"][ts-btn title="LEARN MORE" shape="square" color="white" font_weight="no" align="right"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]',					
				), 
				array(
					'section'	=> array('Service Box'),
					'name'		=> esc_attr('48.jpg'),
					'img'		=> '48.jpg',
					'content'	=> '[vc_row full_width="stretch_row_content_no_spaces"][vc_column][ts-servicebox h2="EXPLORING ANATOMY &amp; PHYSIOLOGY<br/><strong>IN THE LABORATORY</strong>" boxstyle="style-2" box_spacing="0px" show="10" column="five"][/ts-servicebox][/vc_column][/vc_row]',
					
				),
				array(
					'section'	=> array('Research'),
					'name'		=> esc_attr('49.jpg'),
					'img'		=> '49.jpg',
					'content'	=> '[vc_row full_width="stretch_row"][vc_column][ts-portfoliobox h2="CHECK OUR<br/><strong>LATEST CASE STUDIES</strong>" boxstyle="style-1"][/ts-portfoliobox][/vc_column][/vc_row]',
				),
				array(
					'section'	=> array('About'),
					'name'		=> esc_attr('50.jpg'),
					'img'		=> '50.jpg',
					'content'	=> '[vc_row full_width="stretch_row" css=".vc_custom_1535364569059{background-image: url(http://labtechco.themestek.com/wp-content/uploads/2018/06/service-06.jpg?id=6982) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"][vc_column width="1/2"][/vc_column][vc_column width="1/2"][vc_row_inner css=".vc_custom_1531991175334{padding-top: 60px !important;padding-right: 60px !important;padding-bottom: 30px !important;padding-left: 60px !important;background-color: rgba(255,255,255,0.85) !important;*background-color: rgb(255,255,255) !important;}" ts_responsive_css="80641299|colbreak_no|||||||||colbreak_no|||||||||colbreak_no|||||30|0|30|0||colbreak_no|||||||||"][vc_column_inner][ts-heading h2="WERE LOCAL JUST LIKE <strong>YOU WE GOOD WORK</strong>"][/ts-heading][vc_column_text]Praesent pharetra orci odio, ut mattis tellus ullamcorper ornare. Suspendisse ullamcorper metus in erat viverra Praesent pharetra orci odio, ut mattis tellus ullamcorper ornare. Suspendisse ullamcorperviverra , vehicula pharetra dolor accumsan. In arcu ex, rutrum finibus malesuada vel.Praesent pharetra orci odio, ut mattis tellus ullamcorper ornare. Suspendisse ullamcorper metus in erat viverra.[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]',
					
				),

		);

		return isset( $p[ $n ] ) ? $p[ $n ] : $p;
	}
}